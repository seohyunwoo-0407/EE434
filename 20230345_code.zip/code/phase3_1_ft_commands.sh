#!/bin/bash

# ============================================================
# Phase 3-1 Fine-tuning: 최적 하이퍼파라미터 적용
# ============================================================
#
# Phase 3-1 핵심 발견:
# - train2 단독에서 StepLR (lr=0.01)이 baseline (16.26%)을 0.72%p 개선 (15.54%)
# - 이 설정을 train1→train2 fine-tuning에 적용
#
# 전략:
# - train1 pretrain: lr=0.01, StepLR (Phase 1의 10배)
# - train2 fine-tune: lr=0.001, StepLR (pretrain의 1/10, Phase 1의 10배)
# - 목표: Softmax 10.22% 개선 여부 확인
# ============================================================

echo "=========================================="
echo "Phase 3-1 Fine-tuning: 최적 하이퍼파라미터 적용"
echo "목표: Softmax (10.22%) 개선"
echo "=========================================="

TRAIN1=/mnt/home/ee40034/data/train1
TRAIN2=/mnt/home/ee40034/data/train2
VAL=/mnt/home/ee40034/data/val
VAL_LIST=/mnt/home/ee40034/data/val_pairs.csv

# ============================================================
# Step 1: train1 Pretrain (lr=0.01)
# ============================================================

echo "실험 3-1-FT-1: Softmax, lr=0.01, train1 pretrain"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN1} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase3_1_softmax_lr01_train1_pretrain \
    --model ResNet18 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.01 \
    --lr_decay 0.90 \
    --batch_size 100 \
    --nClasses 2882 \
    --max_epoch 12

# ============================================================
# Step 2: train1→train2 Fine-tune (lr=0.001)
# ============================================================
# initial_model은 Step 1 결과에서 최적 epoch 선택
# Phase 1에서는 epoch 4가 best였으므로, 일단 epoch 4 사용
# 필요시 다른 epoch도 시도 가능

echo "실험 3-1-FT-2: Softmax, lr=0.001, train1→train2 fine-tune"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase3_1_softmax_lr01_train1_finetune_train2 \
    --initial_model ./exps/phase3_1_softmax_lr01_train1_pretrain/epoch0004.model \
    --model ResNet18 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.001 \
    --lr_decay 0.90 \
    --batch_size 100 \
    --nClasses 949 \
    --max_epoch 10

echo ""
echo "=========================================="
echo "Phase 3-1 Fine-tuning 완료!"
echo ""
echo "결과 비교:"
echo "- Phase 1 Best: Softmax (lr=0.001→0.0001, train1→train2 FT) = 10.22% EER"
echo "- Phase 3-1: Softmax (lr=0.01→0.001, train1→train2 FT) = ? EER"
echo "=========================================="

