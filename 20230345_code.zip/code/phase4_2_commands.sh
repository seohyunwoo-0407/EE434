#!/bin/bash
# Phase 4-2: Fine-tuning 실험
# Phase 4에서 pretrain한 모델들을 train2로 fine-tuning

# ============================================================
# Phase 4-2: Fine-tuning 실험
# 목표: Phase 4 pretrain 모델들을 train2로 fine-tuning하여 Phase 1 Best (10.22% EER) 개선
# 전략: Phase 1 최적 설정 적용
#   - Loss: Softmax
#   - lr: 0.0001 (pretrain의 1/10)
#   - Optimizer: Adam
#   - Scheduler: StepLR (lr_decay=0.90)
#   - max_epoch: 10
# ============================================================

TRAIN2=/mnt/home/ee40034/data/train2
VAL=/mnt/home/ee40034/data/val
VAL_LIST=/mnt/home/ee40034/data/val_pairs.csv

echo "=========================================="
echo "Phase 4-2: Fine-tuning 실험"
echo "=========================================="

# ============================================================
# 4-1. ResNet18_SE-Net Fine-tuning
# ============================================================

echo ""
echo "=========================================="
echo "4-1-2: ResNet18_SE-Net - train1→train2 fine-tune"
echo "=========================================="
python code/trainEmbedNet.py \
    --gpu 1 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase4_resnet18_senet_train1_finetune_train2 \
    --initial_model ./exps/phase4_resnet18_senet_train1_pretrain/epoch0004.model \
    --model ResNet18_SE-Net \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.90 \
    --nClasses 949 \
    --max_epoch 16

# ============================================================
# 4-2. ResNet34 Fine-tuning
# ============================================================

echo ""
echo "=========================================="
echo "4-2-2: ResNet34 - train1→train2 fine-tune"
echo "=========================================="
python code/trainEmbedNet.py \
    --gpu 1 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase4_resnet34_train1_finetune_train2 \
    --initial_model ./exps/phase4_resnet34_train1_pretrain/epoch0004.model \
    --model ResNet34 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.90 \
    --nClasses 949 \
    --max_epoch 16

# ============================================================
# 4-3. MobileNetV2 Fine-tuning
# ============================================================

echo ""
echo "=========================================="
echo "4-3-2: MobileNetV2 - train1→train2 fine-tune"
echo "=========================================="
python code/trainEmbedNet.py \
    --gpu 1 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase4_mobilenetv2_train1_finetune_train2 \
    --initial_model ./exps/phase4_mobilenetv2_train1_pretrain/epoch0012.model \
    --model MobileNetV2 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.90 \
    --nClasses 949 \
    --max_epoch 16

# ============================================================
# 4-4. EfficientNet-B0 Fine-tuning
# ============================================================

echo ""
echo "=========================================="
echo "4-4-2: EfficientNet-B0 - train1→train2 fine-tune"
echo "=========================================="
echo "주의: pretrain 결과 확인 후 최적 epoch 모델 경로를 수정하세요"
python code/trainEmbedNet.py \
    --gpu 1 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase4_efficientnet_b0_train1_finetune_train2 \
    --initial_model ./exps/phase4_efficientnet_b0_train1_pretrain/epoch0010.model \
    --model EfficientNet-B0 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.90 \
    --batch_size 50 \
    --nClasses 949 \
    --max_epoch 10

# ============================================================
# 4-5. ResNet18_CBAM Fine-tuning
# ============================================================

echo ""
echo "=========================================="
echo "4-5-2: ResNet18_CBAM - train1→train2 fine-tune"
echo "=========================================="
echo "주의: pretrain 결과 확인 후 최적 epoch 모델 경로를 수정하세요"
python code/trainEmbedNet.py \
    --gpu 1 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase4_resnet18_cbam_train1_finetune_train2 \
    --initial_model ./exps/phase4_resnet18_cbam_train1_pretrain/epoch0004.model \
    --model ResNet18_CBAM \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.90 \
    --nClasses 949 \
    --max_epoch 10

echo ""
echo "=========================================="
echo "Phase 4-2 Fine-tuning 실험 완료"
echo "=========================================="
echo ""
echo "참고:"
echo "- Phase 1 Best: Softmax (ResNet18) train1→train2 FT = 10.22% EER"
echo "- 각 모델의 fine-tuning 결과를 Phase 1 Best와 비교"


