#!/bin/bash

# ============================================================
# Phase 2.5: Softmax + ArcFace Combined Loss 실험
# ============================================================
# 
# Phase 2 핵심 발견:
# - ArcFace (13.29%)가 Softmax (10.22%)보다 나쁨
# - Triplet Hard는 실패 (36.93%)
# - Softmax가 최적의 loss function
#
# Phase 2.5 전략:
# - Softmax와 ArcFace를 결합하여 두 loss의 장점 결합
# - 가중치 조합 실험: 0.7:0.3, 0.5:0.5
# - train1 pretrain → train2 fine-tune 전략 적용
# ============================================================

echo "=========================================="
echo "Phase 2.5: Softmax + ArcFace Combined Loss"
echo "목표: Phase 1 Best (10.22%) 개선"
echo "=========================================="

# ============================================================
# Step 1: 가중치 0.7:0.3 (Softmax 우세) 실험
# ============================================================

# 2.5-1. Combined Loss (0.7:0.3) - train1 pretrain
# 기본값: weight_softmax=0.7, weight_arcface=0.3
echo "실험 2.5-1: Combined Loss (0.7:0.3) - train1 pretrain"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path /mnt/home/ee40034/data/train1 \
    --test_path /mnt/home/ee40034/data/val \
    --test_list /mnt/home/ee40034/data/val_pairs.csv \
    --save_path ./exps/phase2_5_combined_07_03_train1_pretrain \
    --model ResNet18 \
    --trainfunc softmax_arcface \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.95 \
    --scale 64 \
    --margin 0.3 \
    --nClasses 2882 \
    --max_epoch 12

# 2.5-3. Combined Loss (0.5:0.5) - train1 pretrain
echo "실험 2.5-3: Combined Loss (0.5:0.5) - train1 pretrain"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path /mnt/home/ee40034/data/train1 \
    --test_path /mnt/home/ee40034/data/val \
    --test_list /mnt/home/ee40034/data/val_pairs.csv \
    --save_path ./exps/phase2_5_combined_05_05_train1_pretrain \
    --model ResNet18 \
    --trainfunc softmax_arcface \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.95 \
    --scale 64 \
    --margin 0.3 \
    --weight_softmax 0.5 \
    --weight_arcface 0.5 \
    --nClasses 2882 \
    --max_epoch 12

# 2.5-2. Combined Loss (0.7:0.3) - train1→train2 fine-tune
# initial_model은 Step 1 결과에서 최적 epoch 선택 (예: epoch0004.model)
echo "실험 2.5-2: Combined Loss (0.7:0.3) train1 → train2 fine-tune"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path /mnt/home/ee40034/data/train2 \
    --test_path /mnt/home/ee40034/data/val \
    --test_list /mnt/home/ee40034/data/val_pairs.csv \
    --save_path ./exps/phase2_5_combined_07_03_train1_finetune_train2 \
    --initial_model ./exps/phase2_5_combined_07_03_train1_pretrain/epoch0008.model \
    --model ResNet18 \
    --trainfunc softmax_arcface \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.90 \
    --scale 64 \
    --margin 0.3 \
    --nClasses 949 \
    --max_epoch 10

# ============================================================
# Step 2: 가중치 0.5:0.5 (균형) 실험
# ============================================================

# 2.5-3. Combined Loss (0.5:0.5) - train1 pretrain
echo "실험 2.5-3: Combined Loss (0.5:0.5) - train1 pretrain"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path /mnt/home/ee40034/data/train1 \
    --test_path /mnt/home/ee40034/data/val \
    --test_list /mnt/home/ee40034/data/val_pairs.csv \
    --save_path ./exps/phase2_5_combined_05_05_train1_pretrain \
    --model ResNet18 \
    --trainfunc softmax_arcface \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.95 \
    --scale 64 \
    --margin 0.3 \
    --weight_softmax 0.5 \
    --weight_arcface 0.5 \
    --nClasses 2882 \
    --max_epoch 12

# 2.5-4. Combined Loss (0.5:0.5) - train1→train2 fine-tune
echo "실험 2.5-4: Combined Loss (0.5:0.5) train1 → train2 fine-tune"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path /mnt/home/ee40034/data/train2 \
    --test_path /mnt/home/ee40034/data/val \
    --test_list /mnt/home/ee40034/data/val_pairs.csv \
    --save_path ./exps/phase2_5_combined_05_05_train1_finetune_train2 \
    --initial_model ./exps/phase2_5_combined_05_05_train1_pretrain/epoch0004.model \
    --model ResNet18 \
    --trainfunc softmax_arcface \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.90 \
    --scale 64 \
    --margin 0.3 \
    --weight_softmax 0.5 \
    --weight_arcface 0.5 \
    --nClasses 949 \
    --max_epoch 10

echo "=========================================="
echo "Phase 2.5 완료!"
echo ""
echo "결과 비교:"
echo "- Phase 1 Best: Softmax (train1→train2 FT) = 10.22% EER"
echo "- Phase 2: ArcFace (train1→train2 FT) = 13.29% EER"
echo "- Phase 2.5: Combined (0.7:0.3, train1→train2 FT) = ? EER"
echo "- Phase 2.5: Combined (0.5:0.5, train1→train2 FT) = ? EER"
echo "=========================================="

