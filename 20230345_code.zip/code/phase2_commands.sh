#!/bin/bash

# ============================================================
# Phase 2: ArcFace Loss 실험 (Phase 1 결과 반영)
# ============================================================
# 
# Phase 1 핵심 발견:
# - Softmax >> Triplet (모든 경우)
# - train1→train2 fine-tuning이 압도적 (10.22% EER)
# - train1 단독은 epoch 4 이후 overfitting
#
# Phase 2 전략:
# Step 1: ArcFace 하이퍼파라미터 탐색 (train2에서 빠르게)
# Step 2: 최적 파라미터로 train1 pretrain → train2 fine-tune
# Step 3: Phase 1 Best (Softmax 10.22%)와 비교
# ================
echo "=========================================="
echo "Step 1 완료: ArcFace 하이퍼파라미터 탐색 결과 확인 후"
echo "최적 파라미터로 Step 2 진행"
echo "=========================================="

# ============================================================
# Step 2: 최적 파라미터로 Fine-tuning 전략 적용
# Step 1 결과: scale=64, margin=0.3이 최적 (33.53% EER at epoch 2)
# ============================================================

# 2-5. ArcFace (best params: s64, m0.3) - train1 pretrain
# train1은 epoch 4 이후 overfitting → 10 epochs만 실행
echo "실험 2-5: ArcFace (s64, m0.3) - train1 pretrain"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path /mnt/home/ee40034/data/train1 \
    --test_path /mnt/home/ee40034/data/val \
    --test_list /mnt/home/ee40034/data/val_pairs.csv \
    --save_path ./exps/phase2_arcface_s64_m03_train1_pretrain \
    --model ResNet18 \
    --trainfunc arcface \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.95 \
    --scale 64 \
    --margin 0.3 \
    --nClasses 2882 \
    --max_epoch 12

# 2-6. ArcFace (train1 pretrain → train2 fine-tune)
# Phase 1에서 가장 효과적이었던 전략 적용
# initial_model은 Step 2-5 결과에서 최적 epoch 선택 (예: epoch0004.model)
echo "실험 2-6: ArcFace (s64, m0.3) train1 → train2 fine-tune"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path /mnt/home/ee40034/data/train2 \
    --test_path /mnt/home/ee40034/data/val \
    --test_list /mnt/home/ee40034/data/val_pairs.csv \
    --save_path ./exps/phase2_arcface_s64_m03_train1_finetune_train2 \
    --initial_model ./exps/phase2_arcface_s64_m03_train1_pretrain/epoch0004.model \
    --model ResNet18 \
    --trainfunc arcface \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.90 \
    --scale 64 \
    --margin 0.3 \
    --nClasses 949 \
    --max_epoch 10

# ============================================================
# Step 3: Triplet Hard (Hard Negative Mining) 검증
# - Phase 1에서 Triplet이 Softmax 대비 크게 뒤처짐
# - Hard Negative Mining으로 개선 여부 확인
# - 우선순위 낮음: 1개 실험만 진행 (margin=0.2)
# ============================================================

# 2-7. Triplet Hard (margin=0.2) - train2
# Phase 1 Triplet (random): 24.40% EER → Hard로 개선 여부 확인
echo "실험 2-7: Triplet Hard (margin=0.2) - train2"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path /mnt/home/ee40034/data/train2 \
    --test_path /mnt/home/ee40034/data/val \
    --test_list /mnt/home/ee40034/data/val_pairs.csv \
    --save_path ./exps/phase2_triplet_hard_m02_train2 \
    --model ResNet18 \
    --trainfunc triplet_hard \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.001 \
    --lr_decay 0.90 \
    --margin 0.2 \
    --nPerClass 2 \
    --nClasses 949 \
    --max_epoch 12

echo "=========================================="
echo "Phase 2 완료!"
echo ""
echo "결과 비교:"
echo "- Phase 1 Best: Softmax (train1→train2 FT) = 10.22% EER"
echo "- Phase 1 Triplet (random): 24.40% EER"
echo "- Phase 2: ArcFace (train1→train2 FT) = ? EER"
echo "- Phase 2: Triplet Hard (train2) = ? EER"
echo "=========================================="

