#!/bin/bash
# Phase 6: Data Augmentation 실험 (단일 전략)
# 목표: Phase 4/5 Best (MobileNetV2, 9.78% EER)에 augmentation 추가하여 개선
# 전략: Phase 4/5 최적 설정 + medium augmentation

# ============================================================
# Phase 6: Data Augmentation 실험 (단일 전략)
# 목표: Phase 4 Best (MobileNetV2 train1→train2 FT, 9.78% EER) 개선
# 
# 최적 설정 고정 (Phase 4/5에서 확정):
#   - 모델: MobileNetV2 (Phase 4 Best)
#   - Loss: Softmax
#   - 하이퍼파라미터: Phase 1 Best 전략
#     * Optimizer: Adam
#     * Scheduler: StepLR (lr_decay=0.90)
#     * Learning Rate: pretrain lr=0.001, fine-tune lr=0.0001
#     * batch_size: 100
#     * nOut: 512
# 
# 선택된 Augmentation 전략: medium (RandomHorizontalFlip + RandomRotation + ColorJitter)
#   - RandomHorizontalFlip(p=0.5) + RandomRotation(±10deg) + ColorJitter
#   - ColorJitter: brightness=0.2, contrast=0.2, saturation=0.2, hue=0.1
# ============================================================

TRAIN1=/mnt/home/ee40034/data/train1
TRAIN2=/mnt/home/ee40034/data/train2
VAL=/mnt/home/ee40034/data/val
VAL_LIST=/mnt/home/ee40034/data/val_pairs.csv

echo "=========================================="
echo "Phase 6: Data Augmentation 실험"
echo "=========================================="

# ============================================================
# Step 1: train1 Pretrain with Medium Augmentation
# ============================================================

echo ""
echo "=========================================="
echo "Step 1: train1 Pretrain (Medium Augmentation 적용)"
echo "=========================================="

# 6-1. Medium Augmentation - train1 pretrain
# Phase 4 Best 모델 (MobileNetV2) + Phase 1 Best 하이퍼파라미터 + Medium Augmentation
echo ""
echo "실험 6-1: MobileNetV2 + Medium Augmentation - train1 pretrain"
echo "모델: MobileNetV2 (Phase 4 Best)"
echo "하이퍼파라미터: Phase 1 Best 전략 (lr=0.001, Adam, StepLR, batch_size=100, nOut=512)"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN1} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase6_mobilenetv2_medium_train1_pretrain \
    --model MobileNetV2 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.001 \
    --lr_decay 0.90 \
    --batch_size 100 \
    --nOut 512 \
    --augmentation medium \
    --nClasses 2882 \
    --max_epoch 16

echo ""
echo "=========================================="
echo "Step 1 완료: 모든 pretrain 실험 종료"
echo "=========================================="
echo ""
echo "다음 단계:"
echo "1. 각 pretrain의 scores.txt를 확인하여 최적 epoch 결정"
echo "2. 아래 fine-tuning 실험의 --initial_model 경로를 최적 epoch로 수정"
echo "3. Step 2의 fine-tuning 실험 실행"
echo ""
read -p "최적 epoch 확인 후 Enter를 눌러 fine-tuning을 진행하세요..."

# ============================================================
# Step 2: train1→train2 Fine-tuning with Medium Augmentation
# ============================================================

echo ""
echo "=========================================="
echo "Step 2: train1→train2 Fine-tuning (Medium Augmentation 적용)"
echo "=========================================="

# 6-2. Medium Augmentation - train1→train2 fine-tune
# 주의: pretrain 결과를 확인하여 최적 epoch 모델을 사용하세요
echo ""
echo "실험 6-2: MobileNetV2 + Medium Augmentation - train1→train2 fine-tune"
echo "모델: MobileNetV2 (Phase 4 Best)"
echo "하이퍼파라미터: Phase 1 Best 전략 (lr=0.0001, Adam, StepLR, batch_size=100, nOut=512)"
echo "주의: pretrain 결과 확인 후 최적 epoch 모델 경로를 수정하세요"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path /mnt/home/ee40034/data/train2 \
    --test_path /mnt/home/ee40034/data/val \
    --test_list /mnt/home/ee40034/data/val_pairs.csv \
    --save_path ./exps/phase6_mobilenetv2_medium_train1_finetune_train2 \
    --initial_model ./exps/phase6_mobilenetv2_medium_train1_pretrain/epoch0014.model \
    --model MobileNetV2 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.90 \
    --batch_size 100 \
    --nOut 512 \
    --augmentation medium \
    --nClasses 949 \
    --max_epoch 24

echo ""
echo "=========================================="
echo "Phase 6 실험 완료"
echo "=========================================="
echo ""
echo "참고:"
echo "- Phase 4 Best: MobileNetV2 train1→train2 FT = 9.78% EER (augmentation: none)"
echo "- Phase 6: MobileNetV2 + Medium Augmentation (RandomHorizontalFlip + RandomRotation + ColorJitter)"
echo "- Fine-tuning 결과를 Phase 4 Best (9.78% EER)와 비교하여 개선 여부 확인"
echo ""
echo "최적 설정 고정:"
echo "  - 모델: MobileNetV2 (Phase 4 Best)"
echo "  - Loss: Softmax"
echo "  - 하이퍼파라미터: Phase 1 Best 전략 (lr=0.001→0.0001, Adam, StepLR, batch_size=100, nOut=512)"
echo "  - Augmentation: medium (Phase 6에서 추가)"

