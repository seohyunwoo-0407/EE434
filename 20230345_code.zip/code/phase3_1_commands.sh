#!/bin/bash

# ============================================================
# Phase 3: 하이퍼파라미터 튜닝 실험 (Softmax 기반)
# ============================================================
#
# Phase 1/2 핵심 요약:
# - Best: Softmax (train1→train2 fine-tune) = 10.22% EER
# - ArcFace, Triplet, Combined Loss 모두 Softmax를 넘지 못함
# - 따라서 Phase 3에서는 Softmax를 기준 loss로 하이퍼파라미터 튜닝
#
# 공통 설정:
# - 모델: ResNet18
# - Loss: Softmax
# - 데이터: train2 (빠른 실험용), train1→train2 FT (최종 검증용)
# - 기준 설정(baseline): lr=0.001 (train2), lr=0.0001 (FT), StepLR(lr_decay=0.90), Adam, batch_size=100, nOut=512
# - 이 스크립트는 우선 train2 단독에서 빠르게 비교 실험을 한 뒤,
#   성능이 좋은 설정을 나중에 train1→train2 FT에 적용하는 용도.
# ============================================================

echo "=========================================="
echo "Phase 3: Hyper-parameter Tuning (Softmax)"
echo "목표: Softmax (train2, 16.26%) 및 FT(10.22%) 성능 개선"
echo "=========================================="

TRAIN2=/mnt/home/ee40034/data/train2
VAL=/mnt/home/ee40034/data/val
VAL_LIST=/mnt/home/ee40034/data/val_pairs.csv

# ------------------------------------------------------------
# 3-1. Learning Rate & Scheduler 실험 (train2, Softmax)
#  - 목표: StepLR에서 lr 스윕 + CosineAnnealingLR 비교
#  - 기준: Phase 1 Softmax train2 (lr=0.001, StepLR, 16.26% EER)
# ------------------------------------------------------------

echo "실험 3-1-x: Learning Rate & Scheduler (train2, Softmax)"

# 3-1-1. lr=0.0005, StepLR (baseline보다 작은 lr)
echo "실험 3-1-1: Softmax, lr=0.0005, StepLR"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase3_softmax_lr0001_steplr_train2 \
    --model ResNet18 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.90 \
    --batch_size 100 \
    --nClasses 949 \
    --max_epoch 12

# 3-1-3. lr=0.005, StepLR (더 큰 lr 실험)
echo "실험 3-1-3: Softmax, lr=0.005, StepLR"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase3_softmax_lr01_steplr_train2 \
    --model ResNet18 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.01 \
    --lr_decay 0.90 \
    --batch_size 100 \
    --nClasses 949 \
    --max_epoch 12

# 3-1-4. lr=0.001, CosineAnnealingLR (스케줄러 비교)
echo "실험 3-1-4: Softmax, lr=0.001, CosineAnnealingLR"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase3_softmax_lr001_cosineanneal_train2 \
    --model ResNet18 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler cosine_annealing \
    --lr 0.001 \
    --lr_decay 0.90 \
    --batch_size 100 \
    --nClasses 949 \
    --max_epoch 12

# 3-1-5. lr=0.001, CosineAnnealingWarmRestarts (SGDR) 비교
echo "실험 3-1-5: Softmax, lr=0.001, CosineAnnealingWarmRestarts (SGDR)"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase3_softmax_lr001_sgdr_train2 \
    --model ResNet18 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler cosine_warm_restarts \
    --lr 0.001 \
    --lr_decay 0.90 \
    --batch_size 100 \
    --nClasses 949 \
    --max_epoch 12

# ============================================================
# 3-1 추가: 수렴할 때까지 추가 학습 (train2 단독)
# - Loss가 계속 감소 중이므로 max_epoch을 늘려서 수렴 확인
# - CosineAnnealingLR이 baseline에 가장 근접하므로 우선 추가 학습
# ============================================================

echo ""
echo "=========================================="
echo "3-1 추가: 수렴할 때까지 추가 학습 (train2)"
echo "목표: Baseline (16.26%) 넘기기"
echo "=========================================="

# 3-1-4-extended. CosineAnnealingLR 추가 학습 (epoch 12 → 24)
# 기존 epoch0012.model을 initial_model로 사용하여 이어서 학습
# 주의: CosineAnnealingLR은 max_epoch=24 기준으로 다시 계산됨 (LR이 다시 높아졌다가 내려감)
echo "실험 3-1-4-extended: CosineAnnealingLR 추가 학습 (12 → 24 epochs)"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase3_softmax_lr001_cosineanneal_train2 \
    --initial_model ./exps/phase3_softmax_lr001_cosineanneal_train2/epoch0012.model \
    --model ResNet18 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler cosine_annealing \
    --lr 0.001 \
    --lr_decay 0.90 \
    --batch_size 100 \
    --nClasses 949 \
    --max_epoch 24

# 3-1-5-extended. SGDR 추가 학습 (epoch 12 → 24)
# CosineAnnealingLR 결과를 보고 필요시 실행
echo "실험 3-1-5-extended: SGDR 추가 학습 (12 → 24 epochs)"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase3_softmax_lr001_sgdr_train2 \
    --initial_model ./exps/phase3_softmax_lr001_sgdr_train2/epoch0012.model \
    --model ResNet18 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler cosine_warm_restarts \
    --lr 0.001 \
    --lr_decay 0.90 \
    --batch_size 100 \
    --nClasses 949 \
    --max_epoch 24

# 3-1-1-extended. StepLR (lr=0.0001) 추가 학습 (epoch 12 → 24)
# 더 작은 LR이므로 더 많은 epoch 필요할 수 있음
echo "실험 3-1-1-extended: StepLR (lr=0.0001) 추가 학습 (12 → 24 epochs)"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase3_softmax_lr0001_steplr_train2 \
    --initial_model ./exps/phase3_softmax_lr0001_steplr_train2/epoch0012.model \
    --model ResNet18 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.90 \
    --batch_size 100 \
    --nClasses 949 \
    --max_epoch 24

echo ""
echo "=========================================="
echo "3-1 추가 학습 완료!"
echo "결과 확인 후 baseline (16.26%) 넘는지 확인"
echo "=========================================="

