#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Phase 4 Fine-tuning 모델들의 EER 감소 그래프 그리기
"""

import re
import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path

# Phase 4 fine-tuning 모델 경로 및 이름
models = {
    'MobileNetV2': 'exps/phase4_mobilenetv2_train1_finetune_train2/scores.txt',
    'ResNet34': 'exps/phase4_resnet34_train1_finetune_train2/scores.txt',
    'ResNet18_SE-Net': 'exps/phase4_resnet18_senet_train1_finetune_train2/scores.txt',
    'ResNet18_CBAM': 'exps/phase4_resnet18_cbam_train1_finetune_train2/scores.txt',
    'EfficientNet-B0': 'exps/phase4_efficientnet_b0_train1_finetune_train2/scores.txt',
}

def parse_scores_file(filepath):
    """
    scores.txt 파일에서 epoch별 EER 추출
    """
    epochs = []
    eers = []
    
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            for line in f:
                # "Epoch XXXX, Val EER Y.YY%" 패턴 찾기
                match = re.search(r'Epoch\s+(\d+),\s+Val\s+EER\s+([\d.]+)%', line)
                if match:
                    epoch = int(match.group(1))
                    eer = float(match.group(2))
                    epochs.append(epoch)
                    eers.append(eer)
    except FileNotFoundError:
        print(f"Warning: {filepath} not found")
        return [], []
    
    return epochs, eers

# 데이터 수집
all_data = {}
for model_name, filepath in models.items():
    epochs, eers = parse_scores_file(filepath)
    if epochs and eers:
        all_data[model_name] = {
            'epochs': epochs,
            'eers': eers
        }
        print(f"{model_name}: {len(epochs)} epochs found")

# 그래프 그리기
plt.figure(figsize=(12, 8))
plt.style.use('seaborn-v0_8-darkgrid')

# 색상 및 마커 설정
colors = {
    'MobileNetV2': '#2E86AB',      # 파란색 (최고 성능)
    'ResNet34': '#A23B72',         # 보라색
    'ResNet18_SE-Net': '#F18F01',  # 주황색
    'ResNet18_CBAM': '#C73E1D',    # 빨간색
    'EfficientNet-B0': '#6A994E',  # 초록색
}

markers = {
    'MobileNetV2': 'o',
    'ResNet34': 's',
    'ResNet18_SE-Net': '^',
    'ResNet18_CBAM': 'D',
    'EfficientNet-B0': 'v',
}

# 각 모델별로 그래프 그리기
for model_name, data in all_data.items():
    epochs = data['epochs']
    eers = data['eers']
    
    plt.plot(epochs, eers, 
             label=model_name,
             color=colors.get(model_name, '#000000'),
             marker=markers.get(model_name, 'o'),
             markersize=6,
             linewidth=2,
             alpha=0.8)

# Phase 1 Best (ResNet18) 기준선 추가
plt.axhline(y=10.22, color='gray', linestyle='--', linewidth=1.5, 
            label='Phase 1 Best (ResNet18, 10.22%)', alpha=0.7)

# 그래프 설정
plt.xlabel('Epoch', fontsize=14, fontweight='bold')
plt.ylabel('EER (%)', fontsize=14, fontweight='bold')
plt.title('Phase 4: Fine-tuning EER Reduction', fontsize=16, fontweight='bold', pad=20)
plt.legend(loc='upper right', fontsize=11, framealpha=0.9)
plt.grid(True, alpha=0.3, linestyle='--')

# Y축 범위 설정 (EER이므로 낮을수록 좋음)
plt.ylim(8.5, 15.5)
plt.xlim(0, max([max(data['epochs']) for data in all_data.values()]) + 1)

# 최고 성능 표시
if 'MobileNetV2' in all_data:
    mob_data = all_data['MobileNetV2']
    min_idx = np.argmin(mob_data['eers'])
    min_epoch = mob_data['epochs'][min_idx]
    min_eer = mob_data['eers'][min_idx]
    plt.annotate(f'Best: {min_eer:.2f}% (E{min_epoch})',
                xy=(min_epoch, min_eer),
                xytext=(min_epoch + 2, min_eer + 0.5),
                arrowprops=dict(arrowstyle='->', color='#2E86AB', lw=1.5),
                fontsize=10, fontweight='bold',
                bbox=dict(boxstyle='round,pad=0.5', facecolor='yellow', alpha=0.7))

plt.tight_layout()

# 저장
output_path = 'exps/phase4_finetune_eer.png'
plt.savefig(output_path, dpi=300, bbox_inches='tight')
print(f"\n그래프가 저장되었습니다: {output_path}")

# 화면에 표시
plt.show()

