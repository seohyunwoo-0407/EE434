# 2.5-2. Combined Loss (0.7:0.3) - train1→train2 fine-tune
# initial_model은 Step 1 결과에서 최적 epoch 선택 (예: epoch0004.model)
echo "실험 2.5-2: Combined Loss (0.7:0.3) train1 → train2 fine-tune"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path /mnt/home/ee40034/data/train2 \
    --test_path /mnt/home/ee40034/data/val \
    --test_list /mnt/home/ee40034/data/val_pairs.csv \
    --save_path ./exps/phase2_5_combined_07_03_train1_finetune_train2 \
    --initial_model ./exps/phase2_5_combined_07_03_train1_pretrain/epoch0008.model \
    --model ResNet18 \
    --trainfunc softmax_arcface \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.90 \
    --scale 64 \
    --margin 0.3 \
    --nClasses 949 \
    --max_epoch 10


# 2.5-4. Combined Loss (0.5:0.5) - train1→train2 fine-tune
echo "실험 2.5-4: Combined Loss (0.5:0.5) train1 → train2 fine-tune"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path /mnt/home/ee40034/data/train2 \
    --test_path /mnt/home/ee40034/data/val \
    --test_list /mnt/home/ee40034/data/val_pairs.csv \
    --save_path ./exps/phase2_5_combined_05_05_train1_finetune_train2 \
    --initial_model ./exps/phase2_5_combined_05_05_train1_pretrain/epoch0006.model \
    --model ResNet18 \
    --trainfunc softmax_arcface \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.90 \
    --scale 64 \
    --margin 0.3 \
    --weight_softmax 0.5 \
    --weight_arcface 0.5 \
    --nClasses 949 \
    --max_epoch 10

