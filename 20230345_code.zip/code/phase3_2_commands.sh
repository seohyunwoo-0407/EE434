# ------------------------------------------------------------
# 3-2. Optimizer & Weight Decay 실험 (train2, Softmax)
# ------------------------------------------------------------
TRAIN2=/mnt/home/ee40034/data/train2
VAL=/mnt/home/ee40034/data/val
VAL_LIST=/mnt/home/ee40034/data/val_pairs.csv

echo "실험 3-1-FT-2: Softmax, lr=0.001, train1→train2 fine-tune"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path /mnt/home/ee40034/data/train2 \
    --test_path /mnt/home/ee40034/data/val \
    --test_list /mnt/home/ee40034/data/val_pairs.csv \
    --save_path ./exps/phase3_1_softmax_lr01_train1_finetune_train2 \
    --initial_model ./exps/phase3_1_softmax_lr01_train1_pretrain/epoch0006.model \
    --model ResNet18 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.001 \
    --lr_decay 0.90 \
    --batch_size 100 \
    --nClasses 949 \
    --max_epoch 12
echo "실험 3-2-x: Optimizer & Weight Decay (train2, Softmax)"

# 3-2-1. AdamW, weight_decay=1e-4
echo "실험 3-2-1: Softmax, AdamW, wd=1e-4"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase3_softmax_adamw_wd1e4_train2 \
    --model ResNet18 \
    --trainfunc softmax \
    --optimizer adamw \
    --scheduler steplr \
    --lr 0.001 \
    --lr_decay 0.90 \
    --weight_decay 1e-4 \
    --batch_size 100 \
    --nClasses 949 \
    --max_epoch 24

# 3-2-2. SGD, momentum=0.9, weight_decay=1e-4
echo "실험 3-2-2: Softmax, SGD, momentum=0.9, wd=1e-4"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase3_softmax_sgd_m09_wd1e4_train2 \
    --model ResNet18 \
    --trainfunc softmax \
    --optimizer sgd \
    --scheduler steplr \
    --lr 0.01 \
    --lr_decay 0.90 \
    --weight_decay 1e-4 \
    --batch_size 100 \
    --nClasses 949 \
    --max_epoch 24

# ------------------------------------------------------------
# 3-3. Batch Size & Embedding Dimension 실험 (train2, Softmax)
# ------------------------------------------------------------

echo "실험 3-3-x: Batch Size & Embedding Dim (train2, Softmax)"

# 3-3-1. batch_size=50, nOut=512
echo "실험 3-3-1: Softmax, batch_size=50, nOut=512"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase3_softmax_bs50_nout512_train2 \
    --model ResNet18 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.001 \
    --lr_decay 0.90 \
    --batch_size 50 \
    --nOut 512 \
    --nClasses 949 \
    --max_epoch 24

# 3-3-2. batch_size=150, nOut=512
echo "실험 3-3-2: Softmax, batch_size=150, nOut=512"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase3_softmax_bs150_nout512_train2 \
    --model ResNet18 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.001 \
    --lr_decay 0.90 \
    --batch_size 150 \
    --nOut 512 \
    --nClasses 949 \
    --max_epoch 24

# 3-3-3. batch_size=100, nOut=256
echo "실험 3-3-3: Softmax, batch_size=100, nOut=256"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase3_softmax_bs100_nout256_train2 \
    --model ResNet18 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.001 \
    --lr_decay 0.90 \
    --batch_size 100 \
    --nOut 256 \
    --nClasses 949 \
    --max_epoch 24

# 3-3-4. batch_size=100, nOut=1024
echo "실험 3-3-4: Softmax, batch_size=100, nOut=1024"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase3_softmax_bs100_nout1024_train2 \
    --model ResNet18 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.001 \
    --lr_decay 0.90 \
    --batch_size 100 \
    --nOut 1024 \
    --nClasses 949 \
    --max_epoch 24

echo "=========================================="
echo "Phase 3 (train2 기준) 하이퍼파라미터 튜닝 명령어 끝"
echo "각 실험의 Best EER를 확인한 뒤, 좋은 설정만 골라"
echo "Softmax train1→train2 fine-tuning에 적용하는 것을 추천."
echo "=========================================="


