TRAIN1=/mnt/home/ee40034/data/train1
VAL=/mnt/home/ee40034/data/val
VAL_LIST=/mnt/home/ee40034/data/val_pairs.csv



# 4-5-1. ResNet18_CBAM - train1 pretrain (12 epochs)
echo ""
echo "실험 4-5-1: ResNet18_CBAM - train1 pretrain (12 epochs)"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN1} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase4_resnet18_cbam_train1_pretrain \
    --model ResNet18_CBAM \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.001 \
    --lr_decay 0.90 \
    --nClasses 2882 \
    --max_epoch 12





echo ""
echo "=========================================="
echo "Phase 4 실험 완료"
echo "=========================================="
echo ""
echo "참고:"
echo "- Phase 1 Best: Softmax (ResNet18) train1→train2 FT = 10.22% EER"
echo "- 각 모델의 fine-tuning 결과를 Phase 1 Best와 비교"
echo "- Tiny_Vit_11m 사용 시 파라미터 수(11.5M 이하) 및 규칙 위배 여부를 반드시 확인"
echo "- 파라미터 수가 11.5M 제한을 초과하는 모델은 제외"
