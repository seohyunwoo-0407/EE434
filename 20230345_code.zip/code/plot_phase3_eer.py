#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Phase 3 하이퍼파라미터 튜닝 실험들의 EER 감소 그래프 그리기
"""

import re
import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path

# Phase 3 주요 실험들
# Phase 3-1: Learning Rate & Scheduler
phase3_1_experiments = {
    'Baseline (lr=0.001)': 'exps/phase1_baseline_softmax_train2/scores.txt',
    'StepLR (lr=0.01)': 'exps/phase3_softmax_lr01_steplr_train2/scores.txt',
    'StepLR (lr=0.0001)': 'exps/phase3_softmax_lr0001_steplr_train2/scores.txt',
    'CosineAnnealingLR (lr=0.001)': 'exps/phase3_softmax_lr001_cosineanneal_train2/scores.txt',
    'SGDR (lr=0.001)': 'exps/phase3_softmax_lr001_sgdr_train2/scores.txt',
}

# Phase 3-2: Optimizer & Weight Decay
phase3_2_experiments = {
    'AdamW (wd=1e-4)': 'exps/phase3_softmax_adamw_wd1e4_train2/scores.txt',
    'SGD (wd=1e-4)': 'exps/phase3_softmax_sgd_m09_wd1e4_train2/scores.txt',
}

# Phase 3-3: Batch Size & Embedding Dimension
phase3_3_experiments = {
    'batch_size=50': 'exps/phase3_softmax_bs50_nout512_train2/scores.txt',
    'batch_size=150': 'exps/phase3_softmax_bs150_nout512_train2/scores.txt',
    'nOut=256': 'exps/phase3_softmax_bs100_nout256_train2/scores.txt',
    'nOut=1024': 'exps/phase3_softmax_bs100_nout1024_train2/scores.txt',
}

def parse_scores_file(filepath):
    """
    scores.txt 파일에서 epoch별 EER 추출
    """
    epochs = []
    eers = []
    
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            for line in f:
                # "Epoch XXXX, Val EER Y.YY%" 패턴 찾기
                match = re.search(r'Epoch\s+(\d+),\s+Val\s+EER\s+([\d.]+)%', line)
                if match:
                    epoch = int(match.group(1))
                    eer = float(match.group(2))
                    epochs.append(epoch)
                    eers.append(eer)
    except FileNotFoundError:
        print(f"Warning: {filepath} not found")
        return [], []
    
    return epochs, eers

# Phase 3-1 데이터 수집
phase3_1_data = {}
for exp_name, filepath in phase3_1_experiments.items():
    epochs, eers = parse_scores_file(filepath)
    if epochs and eers:
        phase3_1_data[exp_name] = {
            'epochs': epochs,
            'eers': eers
        }
        print(f"Phase 3-1 - {exp_name}: {len(epochs)} epochs found")

# Phase 3-2 데이터 수집
phase3_2_data = {}
for exp_name, filepath in phase3_2_experiments.items():
    epochs, eers = parse_scores_file(filepath)
    if epochs and eers:
        phase3_2_data[exp_name] = {
            'epochs': epochs,
            'eers': eers
        }
        print(f"Phase 3-2 - {exp_name}: {len(epochs)} epochs found")

# Phase 3-3 데이터 수집
phase3_3_data = {}
for exp_name, filepath in phase3_3_experiments.items():
    epochs, eers = parse_scores_file(filepath)
    if epochs and eers:
        phase3_3_data[exp_name] = {
            'epochs': epochs,
            'eers': eers
        }
        print(f"Phase 3-3 - {exp_name}: {len(epochs)} epochs found")

# 그래프 1: Phase 3-1 (Learning Rate & Scheduler)
if phase3_1_data:
    plt.figure(figsize=(14, 8))
    plt.style.use('seaborn-v0_8-darkgrid')
    
    colors_3_1 = {
        'Baseline (lr=0.001)': '#808080',  # 회색
        'StepLR (lr=0.01)': '#2E86AB',      # 파란색 (최고 성능)
        'StepLR (lr=0.0001)': '#A23B72',   # 보라색
        'CosineAnnealingLR (lr=0.001)': '#F18F01',  # 주황색
        'SGDR (lr=0.001)': '#C73E1D',      # 빨간색
    }
    
    markers_3_1 = {
        'Baseline (lr=0.001)': 'o',
        'StepLR (lr=0.01)': 's',
        'StepLR (lr=0.0001)': '^',
        'CosineAnnealingLR (lr=0.001)': 'D',
        'SGDR (lr=0.001)': 'v',
    }
    
    for exp_name, data in phase3_1_data.items():
        epochs = data['epochs']
        eers = data['eers']
        
        plt.plot(epochs, eers, 
                 label=exp_name,
                 color=colors_3_1.get(exp_name, '#000000'),
                 marker=markers_3_1.get(exp_name, 'o'),
                 markersize=6,
                 linewidth=2,
                 alpha=0.8)
    
    plt.xlabel('Epoch', fontsize=14, fontweight='bold')
    plt.ylabel('EER (%)', fontsize=14, fontweight='bold')
    plt.title('Phase 3-1: Learning Rate & Scheduler Tuning', fontsize=16, fontweight='bold', pad=20)
    plt.legend(loc='upper right', fontsize=10, framealpha=0.9)
    plt.grid(True, alpha=0.3, linestyle='--')
    plt.ylim(14, 20)
    
    # 최고 성능 표시
    if 'StepLR (lr=0.01)' in phase3_1_data:
        best_data = phase3_1_data['StepLR (lr=0.01)']
        min_idx = np.argmin(best_data['eers'])
        min_epoch = best_data['epochs'][min_idx]
        min_eer = best_data['eers'][min_idx]
        plt.annotate(f'Best: {min_eer:.2f}% (E{min_epoch})',
                    xy=(min_epoch, min_eer),
                    xytext=(min_epoch + 1, min_eer + 0.3),
                    arrowprops=dict(arrowstyle='->', color='#2E86AB', lw=1.5),
                    fontsize=10, fontweight='bold',
                    bbox=dict(boxstyle='round,pad=0.5', facecolor='yellow', alpha=0.7))
    
    plt.tight_layout()
    plt.savefig('exps/phase3_1_eer.png', dpi=300, bbox_inches='tight')
    print(f"\nPhase 3-1 그래프 저장: exps/phase3_1_eer.png")
    plt.close()

# 그래프 2: Phase 3-2 (Optimizer & Weight Decay)
if phase3_2_data:
    plt.figure(figsize=(12, 8))
    plt.style.use('seaborn-v0_8-darkgrid')
    
    # Baseline과 Best도 함께 표시
    if 'Baseline (lr=0.001)' in phase3_1_data:
        baseline_data = phase3_1_data['Baseline (lr=0.001)']
        plt.plot(baseline_data['epochs'], baseline_data['eers'],
                label='Baseline (Adam, wd=0)', color='#808080', 
                marker='o', markersize=6, linewidth=2, linestyle='--', alpha=0.7)
    
    if 'StepLR (lr=0.01)' in phase3_1_data:
        best_data = phase3_1_data['StepLR (lr=0.01)']
        plt.plot(best_data['epochs'], best_data['eers'],
                label='Best (StepLR lr=0.01)', color='#2E86AB',
                marker='s', markersize=6, linewidth=2, alpha=0.7)
    
    colors_3_2 = {
        'AdamW (wd=1e-4)': '#F18F01',
        'SGD (wd=1e-4)': '#C73E1D',
    }
    
    markers_3_2 = {
        'AdamW (wd=1e-4)': '^',
        'SGD (wd=1e-4)': 'D',
    }
    
    for exp_name, data in phase3_2_data.items():
        epochs = data['epochs']
        eers = data['eers']
        
        plt.plot(epochs, eers, 
                 label=exp_name,
                 color=colors_3_2.get(exp_name, '#000000'),
                 marker=markers_3_2.get(exp_name, 'o'),
                 markersize=6,
                 linewidth=2,
                 alpha=0.8)
    
    plt.xlabel('Epoch', fontsize=14, fontweight='bold')
    plt.ylabel('EER (%)', fontsize=14, fontweight='bold')
    plt.title('Phase 3-2: Optimizer & Weight Decay Tuning', fontsize=16, fontweight='bold', pad=20)
    plt.legend(loc='upper right', fontsize=10, framealpha=0.9)
    plt.grid(True, alpha=0.3, linestyle='--')
    plt.ylim(15, 20)
    plt.tight_layout()
    plt.savefig('exps/phase3_2_eer.png', dpi=300, bbox_inches='tight')
    print(f"Phase 3-2 그래프 저장: exps/phase3_2_eer.png")
    plt.close()

# 그래프 3: Phase 3-3 (Batch Size & Embedding Dimension)
if phase3_3_data:
    plt.figure(figsize=(12, 8))
    plt.style.use('seaborn-v0_8-darkgrid')
    
    # Baseline과 Best도 함께 표시
    if 'Baseline (lr=0.001)' in phase3_1_data:
        baseline_data = phase3_1_data['Baseline (lr=0.001)']
        plt.plot(baseline_data['epochs'], baseline_data['eers'],
                label='Baseline (bs=100, nOut=512)', color='#808080',
                marker='o', markersize=6, linewidth=2, linestyle='--', alpha=0.7)
    
    if 'StepLR (lr=0.01)' in phase3_1_data:
        best_data = phase3_1_data['StepLR (lr=0.01)']
        plt.plot(best_data['epochs'], best_data['eers'],
                label='Best (StepLR lr=0.01)', color='#2E86AB',
                marker='s', markersize=6, linewidth=2, alpha=0.7)
    
    colors_3_3 = {
        'batch_size=50': '#F18F01',
        'batch_size=150': '#A23B72',
        'nOut=256': '#6A994E',
        'nOut=1024': '#C73E1D',
    }
    
    markers_3_3 = {
        'batch_size=50': '^',
        'batch_size=150': 'D',
        'nOut=256': 'v',
        'nOut=1024': 's',
    }
    
    for exp_name, data in phase3_3_data.items():
        epochs = data['epochs']
        eers = data['eers']
        
        plt.plot(epochs, eers, 
                 label=exp_name,
                 color=colors_3_3.get(exp_name, '#000000'),
                 marker=markers_3_3.get(exp_name, 'o'),
                 markersize=6,
                 linewidth=2,
                 alpha=0.8)
    
    plt.xlabel('Epoch', fontsize=14, fontweight='bold')
    plt.ylabel('EER (%)', fontsize=14, fontweight='bold')
    plt.title('Phase 3-3: Batch Size & Embedding Dimension Tuning', fontsize=16, fontweight='bold', pad=20)
    plt.legend(loc='upper right', fontsize=10, framealpha=0.9)
    plt.grid(True, alpha=0.3, linestyle='--')
    plt.ylim(15, 18)
    plt.tight_layout()
    plt.savefig('exps/phase3_3_eer.png', dpi=300, bbox_inches='tight')
    print(f"Phase 3-3 그래프 저장: exps/phase3_3_eer.png")
    plt.close()

print("\n모든 Phase 3 그래프 생성 완료!")

