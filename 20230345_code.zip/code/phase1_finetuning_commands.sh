# 1-7. Softmax (train1 pretrain) → train2 fine-tune
# train1에서 가장 좋은 EER(19.78%)을 달성한 epoch4 모델 사용
echo "실험 1-7: Softmax (train1 pretrain → train2 fine-tune)"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path /mnt/home/ee40034/data/train2 \
    --test_path /mnt/home/ee40034/data/val \
    --test_list /mnt/home/ee40034/data/val_pairs.csv \
    --save_path ./exps/phase1_softmax_train1_finetune_train2 \
    --initial_model ./exps/phase1_baseline_softmax_train1/epoch0004.model \
    --model ResNet18 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.90 \
    --nClasses 949 \
    --max_epoch 12

# 1-8. Triplet (train1 pretrain) → train2 fine-tune
# train1에서 가장 좋은 EER(26.40%)을 달성한 epoch10 모델 사용
echo "실험 1-8: Triplet (train1 pretrain → train2 fine-tune)"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path /mnt/home/ee40034/data/train2 \
    --test_path /mnt/home/ee40034/data/val \
    --test_list /mnt/home/ee40034/data/val_pairs.csv \
    --save_path ./exps/phase1_triplet_train1_finetune_train2 \
    --initial_model ./exps/phase1_baseline_triplet_train1/epoch0010.model \
    --model ResNet18 \
    --trainfunc triplet \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.90 \
    --margin 0.1 \
    --nPerClass 2 \
    --max_epoch 12
