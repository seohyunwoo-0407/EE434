#!/bin/bash
# Phase 4: 모델 아키텍처 실험
# Phase 1 최적 설정 (Softmax, train1→train2 fine-tuning)을 다른 모델에 적용

# ============================================================
# Phase 4: 모델 아키텍처 변경 실험
# 목표: Phase 1 Best (Softmax train1→train2 FT, 10.22% EER) 개선
# 전략: Phase 1 최적 설정을 다른 모델에 적용
#   - Loss: Softmax
#   - 전략: train1 pretrain (12 epochs, lr=0.001) → train2 fine-tune (10 epochs, lr=0.0001)
#     * 각 모델의 train1 pretrain에서 최적 epoch를 찾은 후, 그 모델을 사용하여 fine-tuning
#   - Optimizer: Adam
#   - Scheduler: StepLR (lr_decay=0.90)
#   - batch_size: 100, nOut: 512
# ============================================================

TRAIN1=/mnt/home/ee40034/data/train1
TRAIN2=/mnt/home/ee40034/data/train2
VAL=/mnt/home/ee40034/data/val
VAL_LIST=/mnt/home/ee40034/data/val_pairs.csv

echo "=========================================="
echo "Phase 4: 모델 아키텍처 실험"
echo "=========================================="

# ============================================================
# Step 1: 모든 모델의 train1 pretrain 실행
# ============================================================

echo ""
echo "=========================================="
echo "Step 1: train1 Pretrain (모든 모델)"
echo "=========================================="

# 4-1-1. ResNet18_SE-Net - train1 pretrain
# Phase 1과 동일하게 12 epoch로 학습하여 최적 epoch 찾기
echo ""
echo "실험 4-1-1: ResNet18_SE-Net - train1 pretrain (12 epochs)"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN1} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase4_resnet18_senet_train1_pretrain \
    --model ResNet18_SE-Net \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.001 \
    --lr_decay 0.90 \
    --nClasses 2882 \
    --max_epoch 12

# 4-2-1. ResNet34 - train1 pretrain
echo ""
echo "실험 4-2-1: ResNet34 - train1 pretrain (12 epochs)"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN1} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase4_resnet34_train1_pretrain \
    --model ResNet34 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.001 \
    --lr_decay 0.90 \
    --nClasses 2882 \
    --max_epoch 12

# 4-3-1. MobileNetV2 - train1 pretrain
echo ""
echo "실험 4-3-1: MobileNetV2 - train1 pretrain (12 epochs)"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN1} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase4_mobilenetv2_train1_pretrain \
    --model MobileNetV2 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.001 \
    --lr_decay 0.90 \
    --nClasses 2882 \
    --max_epoch 12

# 4-4-1. EfficientNet-B0 - train1 pretrain
echo ""
echo "실험 4-4-1: EfficientNet-B0 - train1 pretrain (12 epochs)"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path /mnt/home/ee40034/data/train1 \
    --test_path /mnt/home/ee40034/data/val \
    --test_list /mnt/home/ee40034/data/val_pairs.csv \
    --save_path ./exps/phase4_efficientnet_b0_train1_pretrain \
    --model EfficientNet-B0 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.001 \
    --lr_decay 0.90 \
    --nClasses 2882 \
    --max_epoch 12 \
    --batch_size 50

echo ""
echo "=========================================="
echo "Step 1 완료: 모든 pretrain 실험 종료"
echo "=========================================="
echo ""
echo "다음 단계:"
echo "1. 각 pretrain의 scores.txt를 확인하여 최적 epoch 결정"
echo "2. 아래 fine-tuning 실험의 --initial_model 경로를 최적 epoch로 수정"
echo "3. Step 2의 fine-tuning 실험 실행"
echo ""
read -p "최적 epoch 확인 후 Enter를 눌러 fine-tuning을 진행하세요..."

# ============================================================
# Step 2: 모든 모델의 train1→train2 fine-tuning 실행
# ============================================================

echo ""
echo "=========================================="
echo "Step 2: train1→train2 Fine-tuning (모든 모델)"
echo "=========================================="

# 4-1-2. ResNet18_SE-Net - train1→train2 fine-tune
# 주의: pretrain 결과를 확인하여 최적 epoch 모델을 사용하세요
# 예: epoch 4가 최적이면 epoch0004.model 사용
echo ""
echo "실험 4-1-2: ResNet18_SE-Net - train1→train2 fine-tune"
echo "주의: pretrain 결과 확인 후 최적 epoch 모델 경로를 수정하세요"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase4_resnet18_senet_train1_finetune_train2 \
    --initial_model ./exps/phase4_resnet18_senet_train1_pretrain/epoch0004.model \
    --model ResNet18_SE-Net \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.90 \
    --nClasses 949 \
    --max_epoch 10

# 4-2-2. ResNet34 - train1→train2 fine-tune
# 주의: pretrain 결과를 확인하여 최적 epoch 모델을 사용하세요
echo ""
echo "실험 4-2-2: ResNet34 - train1→train2 fine-tune"
echo "주의: pretrain 결과 확인 후 최적 epoch 모델 경로를 수정하세요"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase4_resnet34_train1_finetune_train2 \
    --initial_model ./exps/phase4_resnet34_train1_pretrain/epoch0004.model \
    --model ResNet34 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.90 \
    --nClasses 949 \
    --max_epoch 10

# 4-3-2. MobileNetV2 - train1→train2 fine-tune
# 주의: pretrain 결과를 확인하여 최적 epoch 모델을 사용하세요
echo ""
echo "실험 4-3-2: MobileNetV2 - train1→train2 fine-tune"
echo "주의: pretrain 결과 확인 후 최적 epoch 모델 경로를 수정하세요"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase4_mobilenetv2_train1_finetune_train2 \
    --initial_model ./exps/phase4_mobilenetv2_train1_pretrain/epoch0004.model \
    --model MobileNetV2 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.90 \
    --nClasses 949 \
    --max_epoch 10

python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase4_efficientnet_b0_train1_finetune_train2 \
    --initial_model ./exps/phase4_efficientnet_b0_train1_pretrain/epoch0004.model \
    --model EfficientNet-B0 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.90 \
    --nClasses 949 \
    --max_epoch 10

# ============================================================
# 4-5. ResNet18 + CBAM Attention
# ============================================================

# 4-5-1. ResNet18_CBAM - train1 pretrain (12 epochs)
echo ""
echo "실험 4-5-1: ResNet18_CBAM - train1 pretrain (12 epochs)"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN1} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase4_resnet18_cbam_train1_pretrain \
    --model ResNet18_CBAM \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.001 \
    --lr_decay 0.90 \
    --nClasses 2882 \
    --max_epoch 12

# 4-5-2. ResNet18_CBAM - train1→train2 fine-tune
# 주의: pretrain 결과를 확인하여 최적 epoch 모델을 사용하세요
echo ""
echo "실험 4-5-2: ResNet18_CBAM - train1→train2 fine-tune"
echo "주의: pretrain 결과 확인 후 최적 epoch 모델 경로를 수정하세요"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase4_resnet18_cbam_train1_finetune_train2 \
    --initial_model ./exps/phase4_resnet18_cbam_train1_pretrain/epoch0004.model \
    --model ResNet18_CBAM \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.90 \
    --nClasses 949 \
    --max_epoch 10

# ============================================================
# 4-6. Tiny_Vit_11m (선택, Transformer 규칙/파라미터 수 확인 필요)
# ============================================================

# 4-7-1. Tiny_Vit_11m - train1 pretrain (12 epochs)
echo ""
echo "실험 4-7-1: Tiny_Vit_11m - train1 pretrain (12 epochs)"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN1} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase4_tiny_vit_11m_train1_pretrain \
    --model Tiny_Vit_11m \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.001 \
    --lr_decay 0.90 \
    --nClasses 2882 \
    --max_epoch 12

# 4-7-2. Tiny_Vit_11m - train1→train2 fine-tune
echo ""
echo "실험 4-7-2: Tiny_Vit_11m - train1→train2 fine-tune"
echo "주의: pretrain 결과 확인 후 최적 epoch 모델 경로를 수정하세요"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase4_tiny_vit_11m_train1_finetune_train2 \
    --initial_model ./exps/phase4_tiny_vit_11m_train1_pretrain/epoch0004.model \
    --model Tiny_Vit_11m \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.90 \
    --nClasses 949 \
    --max_epoch 10

echo ""
echo "=========================================="
echo "Phase 4 실험 완료"
echo "=========================================="
echo ""
echo "참고:"
echo "- Phase 1 Best: Softmax (ResNet18) train1→train2 FT = 10.22% EER"
echo "- 각 모델의 fine-tuning 결과를 Phase 1 Best와 비교"
echo "- Tiny_Vit_11m 사용 시 파라미터 수(11.5M 이하) 및 규칙 위배 여부를 반드시 확인"
echo "- 파라미터 수가 11.5M 제한을 초과하는 모델은 제외"
