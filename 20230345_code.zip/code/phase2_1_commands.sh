#!/bin/bash

# ============================================================
# Phase 2: ArcFace Loss 실험 (Phase 1 결과 반영)
# ============================================================
# 
# Phase 1 핵심 발견:
# - Softmax >> Triplet (모든 경우)
# - train1→train2 fine-tuning이 압도적 (10.22% EER)
# - train1 단독은 epoch 4 이후 overfitting
#
# Phase 2 전략:
# Step 1: ArcFace 하이퍼파라미터 탐색 (train2에서 빠르게)
# Step 2: 최적 파라미터로 train1 pretrain → train2 fine-tune
# Step 3: Phase 1 Best (Softmax 10.22%)와 비교
# ============================================================

echo "=========================================="
echo "Phase 2: ArcFace 하이퍼파라미터 탐색"
echo "=========================================="

# ============================================================
# Step 1: ArcFace 하이퍼파라미터 탐색 (train2, 빠른 실험)
# train2: 949 classes, ~3분/epoch → 12 epochs = ~36분/실험
# ============================================================

# 2-1. ArcFace (scale=64, margin=0.5) - train2
echo "실험 2-1: ArcFace (scale=64, margin=0.5, train2)"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path /mnt/home/ee40034/data/train2 \
    --test_path /mnt/home/ee40034/data/val \
    --test_list /mnt/home/ee40034/data/val_pairs.csv \
    --save_path ./exps/phase2_arcface_s64_m05_train2 \
    --model ResNet18 \
    --trainfunc arcface \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.001 \
    --lr_decay 0.90 \
    --scale 64 \
    --margin 0.5 \
    --nClasses 949 \
    --max_epoch 12

# 2-2. ArcFace (scale=64, margin=0.3) - train2
echo "실험 2-2: ArcFace (scale=64, margin=0.3, train2)"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path /mnt/home/ee40034/data/train2 \
    --test_path /mnt/home/ee40034/data/val \
    --test_list /mnt/home/ee40034/data/val_pairs.csv \
    --save_path ./exps/phase2_arcface_s64_m03_train2 \
    --model ResNet18 \
    --trainfunc arcface \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.001 \
    --lr_decay 0.90 \
    --scale 64 \
    --margin 0.3 \
    --nClasses 949 \
    --max_epoch 12

# 2-3. ArcFace (scale=30, margin=0.5) - train2
echo "실험 2-3: ArcFace (scale=30, margin=0.5, train2)"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path /mnt/home/ee40034/data/train2 \
    --test_path /mnt/home/ee40034/data/val \
    --test_list /mnt/home/ee40034/data/val_pairs.csv \
    --save_path ./exps/phase2_arcface_s30_m05_train2 \
    --model ResNet18 \
    --trainfunc arcface \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.001 \
    --lr_decay 0.90 \
    --scale 30 \
    --margin 0.5 \
    --nClasses 949 \
    --max_epoch 12

# 2-4. ArcFace (scale=30, margin=0.3) - train2
echo "실험 2-4: ArcFace (scale=30, margin=0.3, train2)"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path /mnt/home/ee40034/data/train2 \
    --test_path /mnt/home/ee40034/data/val \
    --test_list /mnt/home/ee40034/data/val_pairs.csv \
    --save_path ./exps/phase2_arcface_s30_m03_train2 \
    --model ResNet18 \
    --trainfunc arcface \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.001 \
    --lr_decay 0.90 \
    --scale 30 \
    --margin 0.3 \
    --nClasses 949 \
    --max_epoch 12
