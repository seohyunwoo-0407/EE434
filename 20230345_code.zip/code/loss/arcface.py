#! /usr/bin/python
# -*- encoding: utf-8 -*-

import torch
import torch.nn as nn
import torch.nn.functional as F
import math

class LossFunction(nn.Module):
    def __init__(self, nOut, nClasses, scale=64, margin=0.5, **kwargs):
        super(LossFunction, self).__init__()
        
        self.test_normalize = True
        
        self.nOut = nOut
        self.nClasses = nClasses
        self.scale = scale
        self.margin = margin
        
        # Weight matrix for classification
        self.weight = nn.Parameter(torch.FloatTensor(nClasses, nOut))
        nn.init.xavier_uniform_(self.weight)
        
        # Precompute cos(m*theta) values for different m values
        self.cos_m = math.cos(margin)
        self.sin_m = math.sin(margin)
        self.th = math.cos(math.pi - margin)
        self.mm = math.sin(math.pi - margin) * margin
        
        self.criterion = nn.CrossEntropyLoss()
        
        print(f'Initialised ArcFace Loss (scale={scale}, margin={margin})')
    
    def forward(self, x, label=None):
        # Normalize input features and weight matrix
        x_norm = F.normalize(x, p=2, dim=1)
        w_norm = F.normalize(self.weight, p=2, dim=1)
        
        # Compute cosine similarity
        cosine = F.linear(x_norm, w_norm)
        cosine = cosine.clamp(-1 + 1e-7, 1 - 1e-7)  # Numerical stability (avoid exact -1, 1)
        
        # Get target cosine values
        target_cosine = cosine[range(len(label)), label].view(-1, 1)
        
        # Compute cos(theta + m) using cosine formula (more stable than acos + margin + cos)
        # cos(theta + m) = cos(theta)*cos(m) - sin(theta)*sin(m)
        sine = torch.sqrt(1.0 - torch.pow(target_cosine, 2))
        phi = target_cosine * self.cos_m - sine * self.sin_m  # cos(theta + m)
        
        # Apply boundary condition: when cos(theta) < cos(pi - m), use linear penalty
        # This prevents numerical issues when theta + m > pi
        phi = torch.where(target_cosine > self.th, phi, target_cosine - self.mm)
        
        # Create output logits
        output = cosine * 1.0
        output[range(len(label)), label] = phi.view(-1)
        
        # Scale the logits
        output = output * self.scale
        
        # Compute loss
        loss = self.criterion(output, label)
        
        return loss

