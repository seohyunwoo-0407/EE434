#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Phase 1 실험 결과 EER 그래프 그리기
"""

import re
import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path

# Phase 1 실험들
phase1_experiments = {
    # Softmax 실험들
    'Softmax (train1)': 'exps/phase1_baseline_softmax_train1/scores.txt',
    'Softmax (train2)': 'exps/phase1_baseline_softmax_train2/scores.txt',
    'Softmax (train1+train2)': 'exps/phase1_baseline_softmax_train1_train2/scores.txt',
    'Softmax (train1→train2 FT)': 'exps/phase1_softmax_train1_finetune_train2/scores.txt',
    
    # Triplet 실험들
    'Triplet (train1)': 'exps/phase1_baseline_triplet_train1/scores.txt',
    'Triplet (train2)': 'exps/phase1_baseline_triplet_train2/scores.txt',
    'Triplet (train1+train2)': 'exps/phase1_baseline_triplet_train1_train2/scores.txt',
    'Triplet (train1→train2 FT)': 'exps/phase1_triplet_train1_finetune_train2/scores.txt',
}

def parse_scores_file(filepath):
    """
    scores.txt 파일에서 epoch별 EER 추출
    """
    epochs = []
    eers = []
    
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            for line in f:
                # "Epoch XXXX, Val EER Y.YY%" 패턴 찾기
                match = re.search(r'Epoch\s+(\d+),\s+Val\s+EER\s+([\d.]+)%', line)
                if match:
                    epoch = int(match.group(1))
                    eer = float(match.group(2))
                    epochs.append(epoch)
                    eers.append(eer)
    except FileNotFoundError:
        print(f"Warning: {filepath} not found")
        return [], []
    
    return epochs, eers

# 데이터 수집
all_data = {}
for exp_name, filepath in phase1_experiments.items():
    epochs, eers = parse_scores_file(filepath)
    if epochs and eers:
        all_data[exp_name] = {
            'epochs': epochs,
            'eers': eers
        }
        print(f"{exp_name}: {len(epochs)} epochs found")

# 그래프 1: 전체 비교 (Softmax와 Triplet 모두)
if all_data:
    plt.figure(figsize=(16, 10))
    plt.style.use('seaborn-v0_8-darkgrid')
    
    # 색상 설정 (Softmax는 파란색 계열, Triplet은 빨간색 계열)
    colors = {
        'Softmax (train1)': '#4A90E2',           # 파란색
        'Softmax (train2)': '#2E86AB',           # 진한 파란색
        'Softmax (train1+train2)': '#7B9CB0',    # 회색 파란색
        'Softmax (train1→train2 FT)': '#1E88E5', # 밝은 파란색 (최고 성능)
        'Triplet (train1)': '#E53935',            # 빨간색
        'Triplet (train2)': '#C73E1D',           # 진한 빨간색
        'Triplet (train1+train2)': '#D32F2F',    # 중간 빨간색
        'Triplet (train1→train2 FT)': '#F44336', # 밝은 빨간색
    }
    
    markers = {
        'Softmax (train1)': 'o',
        'Softmax (train2)': 's',
        'Softmax (train1+train2)': '^',
        'Softmax (train1→train2 FT)': 'D',
        'Triplet (train1)': 'o',
        'Triplet (train2)': 's',
        'Triplet (train1+train2)': '^',
        'Triplet (train1→train2 FT)': 'D',
    }
    
    linestyles = {
        'Softmax (train1)': '-',
        'Softmax (train2)': '-',
        'Softmax (train1+train2)': '-',
        'Softmax (train1→train2 FT)': '-',
        'Triplet (train1)': '--',
        'Triplet (train2)': '--',
        'Triplet (train1+train2)': '--',
        'Triplet (train1→train2 FT)': '--',
    }
    
    # Softmax 실험들 먼저 그리기
    for exp_name, data in all_data.items():
        if 'Softmax' in exp_name:
            epochs = data['epochs']
            eers = data['eers']
            
            plt.plot(epochs, eers, 
                     label=exp_name,
                     color=colors.get(exp_name, '#000000'),
                     marker=markers.get(exp_name, 'o'),
                     markersize=7,
                     linewidth=2.5,
                     linestyle=linestyles.get(exp_name, '-'),
                     alpha=0.85)
    
    # Triplet 실험들 그리기
    for exp_name, data in all_data.items():
        if 'Triplet' in exp_name:
            epochs = data['epochs']
            eers = data['eers']
            
            plt.plot(epochs, eers, 
                     label=exp_name,
                     color=colors.get(exp_name, '#000000'),
                     marker=markers.get(exp_name, 'o'),
                     markersize=7,
                     linewidth=2.5,
                     linestyle=linestyles.get(exp_name, '--'),
                     alpha=0.85)
    
    plt.xlabel('Epoch', fontsize=14, fontweight='bold')
    plt.ylabel('EER (%)', fontsize=14, fontweight='bold')
    plt.title('Phase 1: Loss Function & Dataset Comparison', fontsize=16, fontweight='bold', pad=20)
    plt.legend(loc='upper right', fontsize=10, framealpha=0.9, ncol=2)
    plt.grid(True, alpha=0.3, linestyle='--')
    plt.ylim(8, 30)
    plt.xlim(0, 13)
    
    # 최고 성능 표시
    if 'Softmax (train1→train2 FT)' in all_data:
        best_data = all_data['Softmax (train1→train2 FT)']
        min_idx = np.argmin(best_data['eers'])
        min_epoch = best_data['epochs'][min_idx]
        min_eer = best_data['eers'][min_idx]
        plt.annotate(f'Best: {min_eer:.2f}% (E{min_epoch})',
                    xy=(min_epoch, min_eer),
                    xytext=(min_epoch + 1, min_eer + 1.5),
                    arrowprops=dict(arrowstyle='->', color='#1E88E5', lw=2),
                    fontsize=11, fontweight='bold',
                    bbox=dict(boxstyle='round,pad=0.5', facecolor='yellow', alpha=0.8))
    
    plt.tight_layout()
    plt.savefig('exps/phase1_all_eer.png', dpi=300, bbox_inches='tight')
    print(f"\nPhase 1 전체 그래프 저장: exps/phase1_all_eer.png")
    plt.close()

# 그래프 2: Softmax만 비교
softmax_data = {k: v for k, v in all_data.items() if 'Softmax' in k}
if softmax_data:
    plt.figure(figsize=(14, 8))
    plt.style.use('seaborn-v0_8-darkgrid')
    
    colors_softmax = {
        'Softmax (train1)': '#4A90E2',
        'Softmax (train2)': '#2E86AB',
        'Softmax (train1+train2)': '#7B9CB0',
        'Softmax (train1→train2 FT)': '#1E88E5',
    }
    
    markers_softmax = {
        'Softmax (train1)': 'o',
        'Softmax (train2)': 's',
        'Softmax (train1+train2)': '^',
        'Softmax (train1→train2 FT)': 'D',
    }
    
    for exp_name, data in softmax_data.items():
        epochs = data['epochs']
        eers = data['eers']
        
        plt.plot(epochs, eers, 
                 label=exp_name,
                 color=colors_softmax.get(exp_name, '#000000'),
                 marker=markers_softmax.get(exp_name, 'o'),
                 markersize=7,
                 linewidth=2.5,
                 alpha=0.85)
    
    plt.xlabel('Epoch', fontsize=14, fontweight='bold')
    plt.ylabel('EER (%)', fontsize=14, fontweight='bold')
    plt.title('Phase 1: Softmax Loss - Dataset Comparison', fontsize=16, fontweight='bold', pad=20)
    plt.legend(loc='upper right', fontsize=11, framealpha=0.9)
    plt.grid(True, alpha=0.3, linestyle='--')
    plt.ylim(8, 26)
    
    # 최고 성능 표시
    if 'Softmax (train1→train2 FT)' in softmax_data:
        best_data = softmax_data['Softmax (train1→train2 FT)']
        min_idx = np.argmin(best_data['eers'])
        min_epoch = best_data['epochs'][min_idx]
        min_eer = best_data['eers'][min_idx]
        plt.annotate(f'Best: {min_eer:.2f}% (E{min_epoch})',
                    xy=(min_epoch, min_eer),
                    xytext=(min_epoch + 1, min_eer + 1.5),
                    arrowprops=dict(arrowstyle='->', color='#1E88E5', lw=2),
                    fontsize=11, fontweight='bold',
                    bbox=dict(boxstyle='round,pad=0.5', facecolor='yellow', alpha=0.8))
    
    plt.tight_layout()
    plt.savefig('exps/phase1_softmax_eer.png', dpi=300, bbox_inches='tight')
    print(f"Phase 1 Softmax 그래프 저장: exps/phase1_softmax_eer.png")
    plt.close()

# 그래프 3: Fine-tuning 전략 비교
finetune_data = {k: v for k, v in all_data.items() if 'FT' in k}
if finetune_data:
    plt.figure(figsize=(12, 8))
    plt.style.use('seaborn-v0_8-darkgrid')
    
    # train2 단독도 함께 표시
    if 'Softmax (train2)' in all_data:
        baseline_data = all_data['Softmax (train2)']
        plt.plot(baseline_data['epochs'], baseline_data['eers'],
                label='Softmax (train2, baseline)', color='#808080',
                marker='o', markersize=6, linewidth=2, linestyle='--', alpha=0.7)
    
    colors_ft = {
        'Softmax (train1→train2 FT)': '#1E88E5',
        'Triplet (train1→train2 FT)': '#F44336',
    }
    
    markers_ft = {
        'Softmax (train1→train2 FT)': 'D',
        'Triplet (train1→train2 FT)': 'D',
    }
    
    for exp_name, data in finetune_data.items():
        epochs = data['epochs']
        eers = data['eers']
        
        plt.plot(epochs, eers, 
                 label=exp_name,
                 color=colors_ft.get(exp_name, '#000000'),
                 marker=markers_ft.get(exp_name, 'o'),
                 markersize=7,
                 linewidth=2.5,
                 alpha=0.85)
    
    plt.xlabel('Epoch', fontsize=14, fontweight='bold')
    plt.ylabel('EER (%)', fontsize=14, fontweight='bold')
    plt.title('Phase 1: Fine-tuning Strategy Comparison', fontsize=16, fontweight='bold', pad=20)
    plt.legend(loc='upper right', fontsize=11, framealpha=0.9)
    plt.grid(True, alpha=0.3, linestyle='--')
    plt.ylim(8, 20)
    
    # 최고 성능 표시
    if 'Softmax (train1→train2 FT)' in finetune_data:
        best_data = finetune_data['Softmax (train1→train2 FT)']
        min_idx = np.argmin(best_data['eers'])
        min_epoch = best_data['epochs'][min_idx]
        min_eer = best_data['eers'][min_idx]
        plt.annotate(f'Best: {min_eer:.2f}% (E{min_epoch})',
                    xy=(min_epoch, min_eer),
                    xytext=(min_epoch + 1, min_eer + 1.5),
                    arrowprops=dict(arrowstyle='->', color='#1E88E5', lw=2),
                    fontsize=11, fontweight='bold',
                    bbox=dict(boxstyle='round,pad=0.5', facecolor='yellow', alpha=0.8))
    
    plt.tight_layout()
    plt.savefig('exps/phase1_finetune_eer.png', dpi=300, bbox_inches='tight')
    print(f"Phase 1 Fine-tuning 그래프 저장: exps/phase1_finetune_eer.png")
    plt.close()

print("\n모든 Phase 1 그래프 생성 완료!")

