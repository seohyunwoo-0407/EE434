#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Phase 1 실험 결과 시각화 스크립트
- 각 실험의 Epoch별 EER을 한 그래프에 표시
- 사용법: python code/visualize_results.py
"""

import os
import re
import glob
import argparse
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')  # GUI 없이 저장용


def parse_scores_file(filepath):
    """
    scores.txt 파일에서 Epoch별 EER 추출
    
    Returns:
        dict: {epoch: eer} 형태
    """
    epochs = []
    eers = []
    
    with open(filepath, 'r') as f:
        for line in f:
            # "Epoch XXXX, Val EER XX.XX%" 패턴 매칭
            match = re.search(r'Epoch (\d+), Val EER ([\d.]+)%', line)
            if match:
                epoch = int(match.group(1))
                eer = float(match.group(2))
                epochs.append(epoch)
                eers.append(eer)
    
    return epochs, eers


def get_experiment_name(exp_path):
    """
    실험 경로에서 간단한 이름 추출
    """
    basename = os.path.basename(exp_path)
    
    # 이름 매핑 (짧고 읽기 쉽게)
    name_map = {
        'phase1_baseline_softmax_train1': 'Softmax (train1)',
        'phase1_baseline_softmax_train2': 'Softmax (train2)',
        'phase1_baseline_triplet_train1': 'Triplet (train1)',
        'phase1_baseline_triplet_train2': 'Triplet (train2)',
        'phase1_baseline_softmax_train1_train2': 'Softmax (train1+2)',
        'phase1_baseline_triplet_train1_train2': 'Triplet (train1+2)',
        'phase1_softmax_train1_finetune_train2': 'Softmax (train1→2 FT)',
        'phase1_triplet_train1_finetune_train2': 'Triplet (train1→2 FT)',
    }
    
    return name_map.get(basename, basename)


def visualize_phase1_results(exps_dir='./exps', output_path='./exps/phase1_eer_comparison.png'):
    """
    Phase 1 실험 결과를 하나의 그래프로 시각화
    """
    # Phase 1 실험 디렉토리 패턴
    exp_patterns = [
        'phase1_baseline_softmax_train1',
        'phase1_baseline_softmax_train2',
        'phase1_baseline_triplet_train1',
        'phase1_baseline_triplet_train2',
        'phase1_baseline_softmax_train1_train2',
        'phase1_baseline_triplet_train1_train2',
        'phase1_softmax_train1_finetune_train2',
        'phase1_triplet_train1_finetune_train2',
    ]
    
    # 색상 및 스타일 설정
    colors = {
        'Softmax (train1)': '#1f77b4',
        'Softmax (train2)': '#2ca02c',
        'Triplet (train1)': '#ff7f0e',
        'Triplet (train2)': '#d62728',
        'Softmax (train1+2)': '#9467bd',
        'Triplet (train1+2)': '#8c564b',
        'Softmax (train1→2 FT)': '#17becf',
        'Triplet (train1→2 FT)': '#bcbd22',
    }
    
    markers = {
        'Softmax (train1)': 'o',
        'Softmax (train2)': 's',
        'Triplet (train1)': '^',
        'Triplet (train2)': 'v',
        'Softmax (train1+2)': 'D',
        'Triplet (train1+2)': 'p',
        'Softmax (train1→2 FT)': '*',
        'Triplet (train1→2 FT)': 'X',
    }
    
    # 그래프 설정
    plt.figure(figsize=(12, 8))
    
    results = {}
    
    for pattern in exp_patterns:
        exp_path = os.path.join(exps_dir, pattern)
        scores_file = os.path.join(exp_path, 'scores.txt')
        
        if os.path.exists(scores_file):
            epochs, eers = parse_scores_file(scores_file)
            if epochs and eers:
                exp_name = get_experiment_name(exp_path)
                results[exp_name] = {'epochs': epochs, 'eers': eers}
                
                # 플롯
                plt.plot(epochs, eers, 
                        label=f'{exp_name} (min: {min(eers):.2f}%)',
                        color=colors.get(exp_name, None),
                        marker=markers.get(exp_name, 'o'),
                        markersize=8,
                        linewidth=2,
                        alpha=0.8)
    
    # 그래프 스타일링
    plt.xlabel('Epoch', fontsize=14)
    plt.ylabel('EER (%)', fontsize=14)
    plt.title('Phase 1: Validation EER Comparison', fontsize=16, fontweight='bold')
    plt.legend(loc='upper right', fontsize=10, framealpha=0.9)
    plt.grid(True, linestyle='--', alpha=0.7)
    
    # Y축 범위 설정 (EER 값에 맞게)
    all_eers = []
    for data in results.values():
        all_eers.extend(data['eers'])
    if all_eers:
        plt.ylim(min(all_eers) - 2, max(all_eers) + 2)
    
    # X축 정수로 표시
    plt.gca().xaxis.set_major_locator(plt.MaxNLocator(integer=True))
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    print(f'그래프 저장 완료: {output_path}')
    
    # 결과 요약 출력
    print('\n' + '='*60)
    print('Phase 1 실험 결과 요약')
    print('='*60)
    
    summary = []
    for exp_name, data in results.items():
        min_eer = min(data['eers'])
        min_epoch = data['epochs'][data['eers'].index(min_eer)]
        final_eer = data['eers'][-1]
        final_epoch = data['epochs'][-1]
        summary.append({
            'name': exp_name,
            'min_eer': min_eer,
            'min_epoch': min_epoch,
            'final_eer': final_eer,
            'final_epoch': final_epoch
        })
    
    # 최저 EER 순으로 정렬
    summary.sort(key=lambda x: x['min_eer'])
    
    print(f'{"실험명":<30} {"최저 EER":<12} {"Epoch":<8} {"최종 EER":<12}')
    print('-'*60)
    for s in summary:
        print(f'{s["name"]:<30} {s["min_eer"]:>6.2f}%      Ep{s["min_epoch"]:<4}   {s["final_eer"]:>6.2f}%')
    
    return results


def visualize_training_loss(exps_dir='./exps', output_path='./exps/phase1_loss_comparison.png'):
    """
    Phase 1 실험의 Training Loss를 시각화
    """
    exp_patterns = [
        'phase1_baseline_softmax_train1',
        'phase1_baseline_softmax_train2',
        'phase1_baseline_triplet_train1',
        'phase1_baseline_triplet_train2',
        'phase1_baseline_softmax_train1_train2',
        'phase1_baseline_triplet_train1_train2',
        'phase1_softmax_train1_finetune_train2',
        'phase1_triplet_train1_finetune_train2',
    ]
    
    plt.figure(figsize=(12, 8))
    
    for pattern in exp_patterns:
        exp_path = os.path.join(exps_dir, pattern)
        scores_file = os.path.join(exp_path, 'scores.txt')
        
        if os.path.exists(scores_file):
            epochs = []
            losses = []
            
            with open(scores_file, 'r') as f:
                for line in f:
                    # "Epoch XXXX completed with TLOSS X.XXXXX" 패턴 매칭
                    match = re.search(r'Epoch (\d+) completed with TLOSS ([\d.]+)', line)
                    if match:
                        epoch = int(match.group(1))
                        loss = float(match.group(2))
                        epochs.append(epoch)
                        losses.append(loss)
            
            if epochs and losses:
                exp_name = get_experiment_name(exp_path)
                plt.plot(epochs, losses, label=exp_name, marker='o', markersize=4, linewidth=1.5)
    
    plt.xlabel('Epoch', fontsize=14)
    plt.ylabel('Training Loss', fontsize=14)
    plt.title('Phase 1: Training Loss Comparison', fontsize=16, fontweight='bold')
    plt.legend(loc='upper right', fontsize=10)
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.yscale('log')  # 로그 스케일 (Loss 범위가 크므로)
    plt.gca().xaxis.set_major_locator(plt.MaxNLocator(integer=True))
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    print(f'Training Loss 그래프 저장 완료: {output_path}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Phase 1 실험 결과 시각화')
    parser.add_argument('--exps_dir', type=str, default='./exps', help='실험 결과 디렉토리')
    parser.add_argument('--output', type=str, default='./exps/phase1_eer_comparison.png', help='출력 파일 경로')
    parser.add_argument('--loss', action='store_true', help='Training Loss도 시각화')
    
    args = parser.parse_args()
    
    # EER 시각화
    visualize_phase1_results(args.exps_dir, args.output)
    
    # Training Loss 시각화 (옵션)
    if args.loss:
        loss_output = args.output.replace('eer', 'loss').replace('.png', '_loss.png')
        if loss_output == args.output:
            loss_output = args.output.replace('.png', '_loss.png')
        visualize_training_loss(args.exps_dir, loss_output)

