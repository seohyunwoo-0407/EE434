#! /usr/bin/python
# -*- encoding: utf-8 -*-
"""
Data Augmentation Strategies for Face Recognition

전략:
- none: 기본 augmentation만 (baseline)
- medium: RandomHorizontalFlip + RandomRotation + ColorJitter
"""

import torchvision.transforms as transforms


def get_augmentation_strategy(strategy='medium', **kwargs):
    """
    Get augmentation transform based on strategy name.
    
    Args:
        strategy: 'none' (baseline), 'medium' (RandomHorizontalFlip + RandomRotation + ColorJitter)
        **kwargs: Additional parameters for specific augmentations (not used currently)
    
    Returns:
        torchvision.transforms.Compose object
    """
    
    # 기본 transform (모든 전략에 공통)
    # 주의: ToTensor()는 PIL Image를 Tensor로 변환하므로, 
    # PIL Image를 받는 transform들(RandomCrop 등)은 ToTensor() 전에 와야 함
    base_transforms = [
        transforms.Resize(256),
        transforms.RandomCrop([224, 224]),
    ]
    
    if strategy == 'none':
        # 기본 augmentation만 (baseline)
        transform_list = base_transforms + [
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ]
    
    elif strategy == 'medium':
        # Medium 전략: 기하학적 + 색상 변환
        # RandomHorizontalFlip + RandomRotation + ColorJitter
        transform_list = base_transforms + [
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.RandomRotation(degrees=10),  # -10 ~ +10도 회전
            transforms.ColorJitter(
                brightness=0.2,    # 밝기 변화 ±20%
                contrast=0.2,      # 대비 변화 ±20%
                saturation=0.2,    # 채도 변화 ±20%
                hue=0.1            # 색상 변화 ±10%
            ),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ]
    
    else:
        raise ValueError(f"Unknown augmentation strategy: {strategy}. "
                        f"Choose from: 'none', 'medium'")
    
    return transforms.Compose(transform_list)


def get_test_transform():
    """
    Get test/validation transform (no augmentation, only normalization).
    
    Returns:
        torchvision.transforms.Compose object
    """
    return transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop([224, 224]),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])

