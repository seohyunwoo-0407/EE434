#! /usr/bin/python
# -*- encoding: utf-8 -*-
"""
MixUp and CutMix Augmentation for Face Recognition

참고: 이 모듈은 DatasetLoader에서 직접 사용하기보다는,
train_network 함수 내에서 batch 단위로 적용하는 것이 일반적입니다.
"""

import torch
import torch.nn as nn
import numpy as np


def mixup_data(x, y, alpha=1.0):
    """
    MixUp augmentation: 두 이미지를 선형 결합
    
    Args:
        x: Input tensor [batch_size, channels, H, W]
        y: Labels tensor [batch_size]
        alpha: Beta distribution parameter (alpha > 0)
    
    Returns:
        mixed_x: Mixed images
        y_a, y_b: Original labels
        lam: Mixing coefficient
    """
    if alpha > 0:
        lam = np.random.beta(alpha, alpha)
    else:
        lam = 1
    
    batch_size = x.size(0)
    index = torch.randperm(batch_size).to(x.device)
    
    mixed_x = lam * x + (1 - lam) * x[index, :]
    y_a, y_b = y, y[index]
    
    return mixed_x, y_a, y_b, lam


def cutmix_data(x, y, alpha=1.0):
    """
    CutMix augmentation: 두 이미지의 일부 영역을 교체
    
    Args:
        x: Input tensor [batch_size, channels, H, W]
        y: Labels tensor [batch_size]
        alpha: Beta distribution parameter (alpha > 0)
    
    Returns:
        mixed_x: Mixed images
        y_a, y_b: Original labels
        lam: Mixing coefficient
    """
    if alpha > 0:
        lam = np.random.beta(alpha, alpha)
    else:
        lam = 1
    
    batch_size = x.size(0)
    index = torch.randperm(batch_size).to(x.device)
    
    # Get bounding box coordinates
    W = x.size(3)
    H = x.size(2)
    cut_rat = np.sqrt(1. - lam)
    cut_w = np.int(W * cut_rat)
    cut_h = np.int(H * cut_rat)
    
    # Random center
    cx = np.random.randint(W)
    cy = np.random.randint(H)
    
    # Clamp bounding box
    bbx1 = np.clip(cx - cut_w // 2, 0, W)
    bby1 = np.clip(cy - cut_h // 2, 0, H)
    bbx2 = np.clip(cx + cut_w // 2, 0, W)
    bby2 = np.clip(cy + cut_h // 2, 0, H)
    
    # Apply CutMix
    mixed_x = x.clone()
    mixed_x[:, :, bby1:bby2, bbx1:bbx2] = x[index, :, bby1:bby2, bbx1:bbx2]
    
    # Adjust lambda to match actual pixel ratio
    lam = 1 - ((bbx2 - bbx1) * (bby2 - bby1) / (W * H))
    
    y_a, y_b = y, y[index]
    
    return mixed_x, y_a, y_b, lam


def mixup_criterion(criterion, pred, y_a, y_b, lam):
    """
    Compute loss for MixUp/CutMix
    
    Args:
        criterion: Loss function
        pred: Model predictions
        y_a, y_b: Mixed labels
        lam: Mixing coefficient
    
    Returns:
        Loss value
    """
    return lam * criterion(pred, y_a) + (1 - lam) * criterion(pred, y_b)

