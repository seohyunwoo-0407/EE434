#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Phase 6: Data Augmentation 효과 비교 그래프
Phase 4 (augmentation='none') vs Phase 6 (augmentation='medium')
"""

import re
import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path

# 실험 파일 경로
experiments = {
    'MobileNetV2 (no augmentation)': 'exps/phase4_mobilenetv2_train1_finetune_train2/scores.txt',
    'MobileNetV2 (medium augmentation)': 'exps/phase6_mobilenetv2_medium_train1_finetune_train2/scores.txt',
}

def parse_scores_file(filepath):
    """
    scores.txt 파일에서 epoch별 EER 추출
    """
    epochs = []
    eers = []
    
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            for line in f:
                # "Epoch XXXX, Val EER Y.YY%" 패턴 찾기
                match = re.search(r'Epoch\s+(\d+),\s+Val\s+EER\s+([\d.]+)%', line)
                if match:
                    epoch = int(match.group(1))
                    eer = float(match.group(2))
                    epochs.append(epoch)
                    eers.append(eer)
    except FileNotFoundError:
        print(f"Warning: {filepath} not found")
        return [], []
    
    return epochs, eers

# 데이터 수집
all_data = {}
for exp_name, filepath in experiments.items():
    epochs, eers = parse_scores_file(filepath)
    if epochs and eers:
        all_data[exp_name] = {
            'epochs': epochs,
            'eers': eers
        }
        print(f"{exp_name}: {len(epochs)} epochs found")
        print(f"  Best EER: {min(eers):.2f}% at Epoch {epochs[np.argmin(eers)]}")

# 그래프 그리기
plt.figure(figsize=(14, 8))
plt.style.use('seaborn-v0_8-darkgrid')

# 색상 및 마커 설정
colors = {
    'MobileNetV2 (no augmentation)': '#E63946',      # 빨간색
    'MobileNetV2 (medium augmentation)': '#2A9D8F',   # 청록색 (Phase 6 Best)
}

markers = {
    'MobileNetV2 (no augmentation)': 'o',
    'MobileNetV2 (medium augmentation)': 's',
}

linewidths = {
    'MobileNetV2 (no augmentation)': 2.5,
    'MobileNetV2 (medium augmentation)': 2.5,
}

# 각 실험별로 그래프 그리기
for exp_name, data in all_data.items():
    epochs = data['epochs']
    eers = data['eers']
    
    # Best EER 표시
    min_idx = np.argmin(eers)
    min_epoch = epochs[min_idx]
    min_eer = eers[min_idx]
    
    plt.plot(epochs, eers, 
             label=f'{exp_name} (Best: {min_eer:.2f}% @ E{min_epoch})',
             color=colors.get(exp_name, '#000000'),
             marker=markers.get(exp_name, 'o'),
             markersize=8,
             linewidth=linewidths.get(exp_name, 2),
             alpha=0.85)
    
    # Best point 강조
    plt.scatter(min_epoch, min_eer, 
               color=colors.get(exp_name, '#000000'),
               s=200, zorder=5, edgecolors='white', linewidths=2)

# Phase 4 Best 기준선 추가
if 'MobileNetV2 (no augmentation)' in all_data:
    phase4_best = min(all_data['MobileNetV2 (no augmentation)']['eers'])
    plt.axhline(y=phase4_best, color='#E63946', linestyle='--', linewidth=1.5, 
                alpha=0.5, label=f'Phase 4 Best ({phase4_best:.2f}%)')

# 그래프 설정
plt.xlabel('Epoch', fontsize=14, fontweight='bold')
plt.ylabel('EER (%)', fontsize=14, fontweight='bold')
plt.title('Phase 6: Data Augmentation Effect Comparison\nMobileNetV2 Fine-tuning (train1→train2)', 
          fontsize=16, fontweight='bold', pad=20)
plt.legend(loc='upper right', fontsize=11, framealpha=0.9)
plt.grid(True, alpha=0.3, linestyle='--')

# Y축 범위 설정 (EER이므로 낮을수록 좋음)
all_eers = []
for data in all_data.values():
    all_eers.extend(data['eers'])
if all_eers:
    plt.ylim(min(all_eers) - 0.5, max(all_eers) + 0.5)

# X축 범위 설정
max_epoch = max([max(data['epochs']) for data in all_data.values()])
plt.xlim(0, max_epoch + 1)

# X축 정수로 표시
plt.gca().xaxis.set_major_locator(plt.MaxNLocator(integer=True))

# 성능 개선 표시
if 'MobileNetV2 (no augmentation)' in all_data and 'MobileNetV2 (medium augmentation)' in all_data:
    phase4_best = min(all_data['MobileNetV2 (no augmentation)']['eers'])
    phase6_best = min(all_data['MobileNetV2 (medium augmentation)']['eers'])
    improvement = phase4_best - phase6_best
    
    # 텍스트 박스 추가
    textstr = f'Improvement: {improvement:.2f}%p\n(Phase 4: {phase4_best:.2f}% → Phase 6: {phase6_best:.2f}%)'
    props = dict(boxstyle='round', facecolor='wheat', alpha=0.8)
    plt.text(0.02, 0.98, textstr, transform=plt.gca().transAxes, 
             fontsize=11, verticalalignment='top', bbox=props, fontweight='bold')

plt.tight_layout()
output_path = 'exps/phase6_augmentation_comparison.png'
plt.savefig(output_path, dpi=150, bbox_inches='tight')
print(f'\n그래프 저장 완료: {output_path}')
plt.close()

