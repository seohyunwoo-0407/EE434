TRAIN2=/mnt/home/ee40034/data/train2
VAL=/mnt/home/ee40034/data/val
VAL_LIST=/mnt/home/ee40034/data/val_pairs.csv

echo "=========================================="
echo "Phase 4-2: Fine-tuning 실험"
echo "=========================================="

# ============================================================
# 4-1. ResNet18_SE-Net Fine-tuning
# ============================================================

echo ""
echo "=========================================="
echo "4-1-2: ResNet18_SE-Net - train1→train2 fine-tune (추가 16ep)"
echo "=========================================="
python code/trainEmbedNet.py \
    --gpu 1 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase4_resnet18_senet_train1_finetune_train2 \
    --initial_model ./exps/phase4_resnet18_senet_train1_finetune_train2/epoch0016.model \
    --model ResNet18_SE-Net \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.90 \
    --nClasses 949 \
    --max_epoch 24

# ============================================================
# 4-2. ResNet34 Fine-tuning
# ============================================================

echo ""
echo "=========================================="
echo "4-2-2: ResNet34 - train1→train2 fine-tune (추가 16ep)"
echo "=========================================="
python code/trainEmbedNet.py \
    --gpu 1 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase4_resnet34_train1_finetune_train2 \
    --initial_model ./exps/phase4_resnet34_train1_finetune_train2/epoch0016.model \
    --model ResNet34 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.90 \
    --nClasses 949 \
    --max_epoch 24

# ============================================================
# 4-3. MobileNetV2 Fine-tuning
# ============================================================

echo ""
echo "=========================================="
echo "4-3-2: MobileNetV2 - train1→train2 fine-tune (추가 16ep)"
echo "=========================================="
python code/trainEmbedNet.py \
    --gpu 1 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase4_mobilenetv2_train1_finetune_train2 \
    --initial_model ./exps/phase4_mobilenetv2_train1_finetune_train2/epoch0016.model \
    --model MobileNetV2 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.90 \
    --nClasses 949 \
    --max_epoch 24

echo ""
echo "=========================================="
echo "4-4-2: EfficientNet-B0 - train1→train2 fine-tune (추가 16ep)"
echo "=========================================="
python code/trainEmbedNet.py \
    --gpu 1 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase4_efficientnet_b0_train1_finetune_train2 \
    --initial_model ./exps/phase4_efficientnet_b0_train1_finetune_train2/epoch0016.model \
    --model EfficientNet-B0 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.90 \
    --batch_size 50 \
    --nClasses 949 \
    --max_epoch 24

echo ""
echo "=========================================="
echo "4-5-2: ResNet18_CBAM - train1→train2 fine-tune"
echo "=========================================="
echo "주의: pretrain 결과 확인 후 최적 epoch 모델 경로를 수정하세요"
python code/trainEmbedNet.py \
    --gpu 1 \
    --train_path /mnt/home/ee40034/data/train2 \
    --test_path /mnt/home/ee40034/data/val \
    --test_list /mnt/home/ee40034/data/val_pairs.csv \
    --save_path ./exps/phase4_resnet18_cbam_train1_finetune_train2 \
    --initial_model ./exps/phase4_resnet18_cbam_train1_pretrain/epoch0008.model \
    --model ResNet18_CBAM \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.90 \
    --nClasses 949 \
    --max_epoch 24