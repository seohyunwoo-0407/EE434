#!/bin/bash

# ============================================================
# 3-1 추가: 수렴할 때까지 추가 학습 (train2 단독)
# - Loss가 계속 감소 중이므로 max_epoch을 늘려서 수렴 확인
# - CosineAnnealingLR이 baseline에 가장 근접하므로 우선 추가 학습
# ============================================================

TRAIN2=/mnt/home/ee40034/data/train2
VAL=/mnt/home/ee40034/data/val
VAL_LIST=/mnt/home/ee40034/data/val_pairs.csv

echo ""
echo "=========================================="
echo "3-1 추가: 수렴할 때까지 추가 학습 (train2)"
echo "목표: Baseline (16.26%) 넘기기"
echo "=========================================="

# 3-1-4-extended. CosineAnnealingLR 추가 학습 (epoch 12 → 24)
# 기존 epoch0012.model을 initial_model로 사용하여 이어서 학습
# 주의: CosineAnnealingLR은 max_epoch=24 기준으로 다시 계산됨 (LR이 다시 높아졌다가 내려감)
echo "실험 3-1-4-extended: CosineAnnealingLR 추가 학습 (12 → 24 epochs)"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase3_softmax_lr001_cosineanneal_train2 \
    --initial_model ./exps/phase3_softmax_lr001_cosineanneal_train2/epoch0012.model \
    --model ResNet18 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler cosine_annealing \
    --lr 0.001 \
    --lr_decay 0.90 \
    --batch_size 100 \
    --nClasses 949 \
    --max_epoch 24

# 3-1-5-extended. SGDR 추가 학습 (epoch 12 → 24)
# CosineAnnealingLR 결과를 보고 필요시 실행
echo "실험 3-1-5-extended: SGDR 추가 학습 (12 → 24 epochs)"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase3_softmax_lr001_sgdr_train2 \
    --initial_model ./exps/phase3_softmax_lr001_sgdr_train2/epoch0012.model \
    --model ResNet18 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler cosine_warm_restarts \
    --lr 0.001 \
    --lr_decay 0.90 \
    --batch_size 100 \
    --nClasses 949 \
    --max_epoch 24

# 3-1-1-extended. StepLR (lr=0.0001) 추가 학습 (epoch 12 → 24)
# 더 작은 LR이므로 더 많은 epoch 필요할 수 있음
echo "실험 3-1-1-extended: StepLR (lr=0.0001) 추가 학습 (12 → 24 epochs)"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase3_softmax_lr0001_steplr_train2 \
    --initial_model ./exps/phase3_softmax_lr0001_steplr_train2/epoch0012.model \
    --model ResNet18 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.0001 \
    --lr_decay 0.90 \
    --batch_size 100 \
    --nClasses 949 \
    --max_epoch 24


echo "실험 3-1-1-extended: StepLR (lr=0.01) 추가 학습 (12 → 24 epochs)"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase3_softmax_lr01_steplr_train2 \
    --initial_model ./exps/phase3_softmax_lr01_steplr_train2/epoch0012.model \
    --model ResNet18 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.01 \
    --lr_decay 0.90 \
    --batch_size 100 \
    --nClasses 949 \
    --max_epoch 24

# 3-1-baseline-extended. Baseline (StepLR, lr=0.001) 추가 학습 (epoch 12 → 24)
# Phase 1 baseline도 추가 학습하여 비교 기준 확보
echo "실험 3-1-baseline-extended: Baseline (StepLR, lr=0.001) 추가 학습 (12 → 24 epochs)"
python code/trainEmbedNet.py \
    --gpu 0 \
    --train_path ${TRAIN2} \
    --test_path ${VAL} \
    --test_list ${VAL_LIST} \
    --save_path ./exps/phase1_baseline_softmax_train2 \
    --initial_model ./exps/phase1_baseline_softmax_train2/epoch0012.model \
    --model ResNet18 \
    --trainfunc softmax \
    --optimizer adam \
    --scheduler steplr \
    --lr 0.001 \
    --lr_decay 0.90 \
    --batch_size 100 \
    --nClasses 949 \
    --max_epoch 24

echo ""
echo "=========================================="
echo "3-1 추가 학습 완료!"
echo "결과 확인 후 baseline (16.26%) 넘는지 확인"
echo "=========================================="

